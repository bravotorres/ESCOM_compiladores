#if !defined(READLINE_H)
#define READLINE_H

#include "fp_t.h"

/* Set dimensions that are fixed at compile time, but whose default
   values may be overridden by compile-time -DMAX_xxx=nnn options.
   Some of these have documented minimum values (see hoc.1) which must
   be enforced here.  All are made available for user inspection in
   __MAX_xxx__ predefined constants. */

#if !defined(MAX_PUSHBACK)
#define MAX_PUSHBACK	10240		/* needs to be big for eval() command support */
#endif
#if (MAX_PUSHBACK + 0) < 10240		/* avoid silly small values */
#undef MAX_PUSHBACK
#define MAX_PUSHBACK	10240
#endif

#if !defined(MAX_TOKEN)
#define MAX_TOKEN	512
#endif
#if (MAX_TOKEN + 0) < 63		/* avoid silly small values */
#undef MAX_TOKEN
#define MAX_TOKEN	63
#endif

#if defined(HAVE_READLINE_READLINE_H)
#include <readline/readline.h>
#endif

#if defined(HAVE_READLINE_HISTORY_H)
#include <readline/history.h>
#endif

/* Interface from readline.c to hoc.y */

extern int		irl_fd_stdin;

extern int		irl_fscanf ARGS((FILE *,const char *,void *));
extern int		irl_getchar ARGS((FILE *));
extern void		irl_unget_char ARGS((int));
extern void		irl_push_input ARGS((void));
extern void		irl_pop_input ARGS((void));

/* Interface from hoc.y to readline.c */

extern void		execerror ARGS((const char*, const char*));
extern const char*	get_prompt ARGS((void));
extern int		get_verbose ARGS((void));

/* Interface from symbol.c to readline.c */

extern const char *	dupstr ARGS((const char *));
extern const char *	first_symbol_pname ARGS((void));
extern const char *	next_symbol_pname ARGS((void));

#endif /* !defined(READLINE_H)) */
