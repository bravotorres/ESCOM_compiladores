#include "hoc.h"
#include "y.tab.h"

#if defined(HAVE_CTYPE_H)
#include <ctype.h>
#endif

#if defined(HAVE_STDIO_H)
#include <stdio.h>
#endif

#if defined(HAVE_STRING_H)
#include <string.h>
#endif

#include "readline.h"
#undef getc
#define getc(fpin)			irl_getchar(fpin)
#undef ungetc
#define ungetc(c,fpin)			irl_unget_char(c)
#undef fscanf
#define fscanf(fpin,format,pdata)	irl_fscanf(fpin,format,pdata)

#if !defined(MAX_STACK)
#define	MAX_STACK	2560
#endif

static Datum stack[MAX_STACK];	/* the stack */
static Datum *stackp;		/* next free spot on stack */

#if !defined(MAX_PROG)
#define	MAX_PROG	32767
#endif

Inst	prog[MAX_PROG];	/* the machine */
Inst	*progp;		/* next free spot for code generation */
Inst	*pc;		/* program counter during execution */
Inst	*progbase = prog; /* start of current subprogram */
int	returning;	/* 1 if return stmt seen */
extern int	indef;	/* 1 if parsing a func or proc */
extern FILE *fin;
extern FILE *fplog;
extern int logfile_enabled;		/* defined in hoc.y */
extern const char *	yygetstr ARGS((void));
extern Symbol *		yygetid ARGS((void));

typedef struct Frame {	/* proc/func call stack frame */
	Symbol	*sp;	/* symbol table entry */
	Inst	*retpc;	/* where to resume after return */
	Datum	*argn;	/* n-th argument on stack */
	long	nargs;	/* number of arguments */
} Frame;

static Datum pop ARGS((void));
static void push ARGS((Datum));
static void verify ARGS((Symbol*));

#if !defined(MAX_FRAME)
#define	MAX_FRAME	1024
#endif

Frame	frame[MAX_FRAME];
Frame	*fp;		/* frame pointer */

void
abort_user(void)			/* abort with message */
{
	Datum d;
	d.sym = (Symbol *)(*pc++);
	execerror("execution aborted:", d.sym->u.str);
}

const char *
Evalcommands(const char *commands)
{
	if (commands != (const char *)NULL)
	{
		const char *last;
		last = strchr(commands,'\0');
		(void)ungetc((int)';', fin); /* semicolon, not newline, to preserve linenumber */
		while (--last >= commands) /* NB: Needs DEEP pushback buffer */
			(void)ungetc((int)*last, fin);
	}
	return ("");
}

const char *
fmtnum(fp_t x)
{	/* Return a decimal representation of x in a static buffer
	that will be overwritten on the next call.  Because of
	variations in the handling of Inf and NaN by printf()
	implementations, we must handle them specially. */

	static char buffer[sizeof("+0.123456789012345678901234567890123456789e+9999")];
			/* big enough for 128-bit precision (NB: this
			relies on get_precision() returning a value in
			0..35) */

	if (IsInf(x))
		(void)sprintf(buffer, "%s", Inf_string(x));
	else if (IsNaN(x))
		(void)sprintf(buffer, "%s", NaN_string(x));
	else
		(void)sprintf(buffer, "%.*g", get_precision(), (double)x);

	return ((const char*)&buffer[0]);
}

void
hex(void)
{
	char buffer[sizeof("0xhhhhhhhh_hhhhhhhh")];
	Datum v;
	DoubleParts d;
	int big_endian = IsBigEndian();

	v = pop();
	d.v = v.val;
	(void)sprintf(buffer, "0x%08x_%08x", d.i[1 - big_endian], d.i[big_endian]);
	prtext(buffer);
	prtext(" == ");
	prtext(xdbltos(d.v));
	prtext(" ");
	push(v);
}

void
hexfp(void)
{
	Datum d1, d2;

	d1 = pop();
	d2.str = dupstr(xdbltos(d1.val));
	push(d2);
}

void
hexint(void)
{
	Datum d1, d2;

	d1 = pop();
	d2.str = dupstr(xinttos(d1.val));
	push(d2);
}

void
initcode(void)
{
	progp = progbase;
	stackp = stack;
	fp = frame;
	returning = 0;
	indef = 0;
}

void
numtostr(void)
{
	Datum d1, d2;

	d1 = pop();
	d2.str = dupstr(fmtnum(d1.val));
	push(d2);
}

static void
push(Datum d)
{
	if (stackp >= &stack[MAX_STACK])
		execerror("stack too deep", (const char*)NULL);
	*stackp++ = d;
#if defined(DEBUG_POP)
	{
		Datum d;
		size_t depth;

		d = stackp[-1];

		depth = (size_t)(stackp - stack);
		(void)fflush(stdout);		/* force out any buffered data */
		(void)fflush(stderr);
		(void)fprintf(stderr,"------------------------------------------------------------\n");
#if 0
		(void)fprintf(stderr, "push(): stack depth %lu top = [%g \"%.39s\" 0x%08x]\n",
			      (unsigned long)depth, d.val, d.str, d.sym);
#else
		(void)fprintf(stderr, "push(): stack depth %lu top = [%g 0x%08x]\n",
			      (unsigned long)depth, d.val, d.sym);
#endif
		(void)fflush(stderr);
	}
#endif
}

static Datum
pop(void)
{
#if defined(DEBUG_POP)
	Datum d;
	if (stackp > stack)
	{
		size_t depth;

		d = stackp[-1];

		depth = (size_t)(stackp - stack);
		(void)fflush(stdout);		/* force out any buffered data */
		(void)fflush(stderr);
#if 0
		(void)fprintf(stderr, "pop():  stack depth %lu top = [%g \"%.39s\" 0x%08x]\n",
			      (unsigned long)depth, d.val, d.str, d.sym);
#else
		(void)fprintf(stderr, "pop():  stack depth %lu top = [%g 0x%08x]\n",
			      (unsigned long)depth, d.val, d.sym);
#endif
		(void)fflush(stderr);
	}
#endif
	if (stackp == stack)
		execerror("stack underflow", (const char*)NULL);
	return *--stackp;
}

void
xpop(void)	/* for when no value is wanted */
{
	(void)pop();
}

void
constpush(void)
{
	Datum d;
	d.val = ((Symbol *)*pc++)->u.val;
	push(d);
}

void
varpush(void)
{
	Datum d;
	d.sym = (Symbol *)(*pc++);
	push(d);
}

void
whilecode(void)
{
	Datum d;
	Inst *savepc = pc;

	execute(savepc+2);	/* condition */
	d = pop();
	while (d.val) {
		execute(*((Inst **)(savepc)));	/* body */
		if (returning)
			break;
		execute(savepc+2);	/* condition */
		d = pop();
	}
	if (!returning)
		pc = *((Inst **)(savepc+1)); /* next stmt */
}

void
forcode(void)
{
	Datum d;
	Inst *savepc = pc;

	execute(savepc+4);		/* precharge */
	xpop();
	execute(*((Inst **)(savepc)));	/* condition */
	d = pop();
	while (d.val) {
		execute(*((Inst **)(savepc+2)));	/* body */
		if (returning)
			break;
		execute(*((Inst **)(savepc+1)));	/* post loop */
		xpop();
		execute(*((Inst **)(savepc)));	/* condition */
		d = pop();
	}
	if (!returning)
		pc = *((Inst **)(savepc+3)); /* next stmt */
}

void
ifcode(void)
{
	Datum d;
	Inst *savepc = pc;	/* then part */

	execute(savepc+3);	/* condition */
	d = pop();
	if (d.val)
		execute(*((Inst **)(savepc)));
	else if (*((Inst **)(savepc+1))) /* else part? */
		execute(*((Inst **)(savepc+1)));
	if (!returning)
		pc = *((Inst **)(savepc+2)); /* next stmt */
}

void
define(Symbol* sp)	/* put func/proc in symbol table */
{
	sp->u.defn = progbase;	/* start of code */
	progbase = progp;	/* next code starts here */
}

void
call(void) 		/* call a function */
{
	Symbol *sp = (Symbol *)pc[0]; /* symbol table entry */
				      /* for function */
	if (fp++ >= &frame[MAX_FRAME-1])
		execerror(sp->name, "call nested too deeply");
	fp->sp = sp;
	fp->nargs = (long)pc[1];
	fp->retpc = pc + 2;
	fp->argn = stackp - 1;	/* last argument */
	execute(sp->u.defn);
	returning = 0;
}

static void
ret(void) 		/* common return from func or proc */
{
	int i;
	for (i = 0; i < fp->nargs; i++)
		xpop();	/* pop arguments */
	pc = (Inst *)fp->retpc;
	--fp;
	returning = 1;
}

void
funcret(void) 	/* return from a function */
{
	Datum d;
	if (fp->sp->type == PROCEDURE)
		execerror(fp->sp->name, "(proc) returns value");
	d = pop();	/* preserve function return value */
	ret();
	push(d);
}

void
procret(void) 	/* return from a procedure */
{
	if (fp->sp->type == FUNCTION)
		execerror(fp->sp->name,
			"(func) returns no value");
	ret();
}

static fp_t*
getarg(void) 	/* return pointer to argument */
{
	long nargs = (long) *pc++;
	if (nargs > fp->nargs)
	    execerror(fp->sp->name, "not enough arguments");
	return &fp->argn[nargs - fp->nargs].val;
}

void
arg(void) 	/* push argument onto stack */
{
	Datum d;
	d.val = *getarg();
	push(d);
}

void
argassign(void) 	/* store top of stack in argument */
{
	Datum d;
	d = pop();
	push(d);	/* leave value on stack */
	*getarg() = d.val;
}

void
argaddeq(void) 	/* store top of stack in argument */
{
	Datum d;
	d = pop();
	d.val = *getarg() += d.val;
	push(d);	/* leave value on stack */
}

void
argsubeq(void) 	/* store top of stack in argument */
{
	Datum d;
	d = pop();
	d.val = *getarg() -= d.val;
	push(d);	/* leave value on stack */
}

void
argmuleq(void) 	/* store top of stack in argument */
{
	Datum d;
	d = pop();
	d.val = *getarg() *= d.val;
	push(d);	/* leave value on stack */
}

void
argdiveq(void) 	/* store top of stack in argument */
{
	Datum d;
	d = pop();
	d.val = *getarg() /= d.val;
	push(d);	/* leave value on stack */
}

void
argmodeq(void) 	/* store top of stack in argument */
{
	Datum d;
	fp_t *x;
	long y;
	d = pop();
	/* d.val = *getarg() %= d.val; */
	x = getarg();
	y = (long)*x;
	d.val = *x = y % (long) d.val;
	push(d);	/* leave value on stack */
}

void
bltin0(void)
{

	Datum d;
	d.val = ((F0_t)*pc++)();
	push(d);
}

void
bltin1(void)
{

	Datum d;
	d = pop();
	d.val = ((F1_t)*pc++)(d.val);
	push(d);
}

void
bltin2(void)
{

	Datum d1, d2;
	d2 = pop();
	d1 = pop();
	d1.val = ((F2_t)*pc++)(d1.val, d2.val);
	push(d1);
}

void
add(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();
	d1.val += d2.val;
	push(d1);
}

void
sub(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();
	d1.val -= d2.val;
	push(d1);
}

void
mul(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();
	d1.val *= d2.val;
	push(d1);
}

void
divop(void)
{
	Datum d1, d2;
	d2 = pop();
#if defined(HAVE_IEEE_754)
	/* zero divide silently produces Inf or NaN */
#else
	if (d2.val == 0.0)
		execerror("division by zero", (const char*)NULL);
#endif
	d1 = pop();
	d1.val /= d2.val;
	push(d1);
}

void
mod(void)
{
	Datum d1, d2;
	LONG_LONG x;
	d2 = pop();
	if (d2.val == 0.0)
		execerror("division by zero", (const char*)NULL);
	d1 = pop();
	/* d1.val %= d2.val; */
	x = (LONG_LONG)d1.val;
	x %= (LONG_LONG)d2.val;
	d1.val = (fp_t)x;
	push(d1);
}

void
negate(void)
{
	Datum d;
	d = pop();
	d.val = -d.val;
	push(d);
}

void
noop(void)
{
}

static void
verify(Symbol* s)
{
	if (s->type != VAR && s->type != UNDEF)
		execerror("attempt to evaluate non-variable", s->name);
	if (s->type == UNDEF)
		execerror("undefined variable", s->name);
}

void
eval(void)		/* evaluate variable on stack */
{
	Datum d;
	d = pop();
	verify(d.sym);
	d.val = d.sym->u.val;
	push(d);
}

void
preinc(void)
{
	Datum d;
	d.sym = (Symbol *)(*pc++);
	verify(d.sym);
	d.val = d.sym->u.val += 1.0;
	push(d);
}

void
predec(void)
{
	Datum d;
	d.sym = (Symbol *)(*pc++);
	verify(d.sym);
	d.val = d.sym->u.val -= 1.0;
	push(d);
}

void
postinc(void)
{
	Datum d;
	fp_t v;
	d.sym = (Symbol *)(*pc++);
	verify(d.sym);
	v = d.sym->u.val;
	d.sym->u.val += 1.0;
	d.val = v;
	push(d);
}

void
postdec(void)
{
	Datum d;
	fp_t v;
	d.sym = (Symbol *)(*pc++);
	verify(d.sym);
	v = d.sym->u.val;
	d.sym->u.val -= 1.0;
	d.val = v;
	push(d);
}

void
gt(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

#if defined(HAVE_NAN_BOTCH)
	if (IsNaN(d1.val) || IsNaN(d2.val))
	{
		d1.val = 0.0;
		push(d1);
		return;
	}
#endif

	d1.val = (fp_t)(d1.val > d2.val);
	push(d1);
}

void
lt(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

#if defined(HAVE_NAN_BOTCH)
	if (IsNaN(d1.val) || IsNaN(d2.val))
	{
		d1.val = 0.0;
		push(d1);
		return;
	}
#endif

	d1.val = (fp_t)(d1.val < d2.val);
	push(d1);
}

void
ge(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

#if defined(HAVE_NAN_BOTCH)
	if (IsNaN(d1.val) || IsNaN(d2.val))
	{
		d1.val = 0.0;
		push(d1);
		return;
	}
#endif

	d1.val = (fp_t)(d1.val >= d2.val);
	push(d1);
}

void
le(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

#if defined(HAVE_NAN_BOTCH)
	if (IsNaN(d1.val) || IsNaN(d2.val))
	{
		d1.val = 0.0;
		push(d1);
		return;
	}
#endif

	d1.val = (fp_t)(d1.val <= d2.val);
	push(d1);
}

void
eq(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

#if defined(HAVE_NAN_BOTCH)
	if (IsNaN(d1.val) || IsNaN(d2.val))
	{
		d1.val = 0.0;
		push(d1);
		return;
	}
#endif

	d1.val = (fp_t)(d1.val == d2.val);
	push(d1);
}

void
ne(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

#if defined(HAVE_NAN_BOTCH)
	if (IsNaN(d1.val) || IsNaN(d2.val))
	{
		d1.val = 1.0;
		push(d1);
		return;
	}
#endif

	d1.val = (fp_t)(d1.val != d2.val);
	push(d1);
}

void
And(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();
	d1.val = (fp_t)(d1.val != 0.0 && d2.val != 0.0);
	push(d1);
}

void
Or(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();
	d1.val = (fp_t)(d1.val != 0.0 || d2.val != 0.0);
	push(d1);
}

void
Not(void)
{
	Datum d;
	d = pop();
	d.val = (fp_t)(d.val == 0.0);
	push(d);
}

void
power(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();
	d1.val = Pow(d1.val, d2.val);
	push(d1);
}

void
assign(void)
{
	Datum d1, d2;
	d1 = pop();
	d2 = pop();
	if (d1.sym->type == STRVAR)	/* perhaps we will rescind this restriction in the future */
		execerror("illegal assignment of number to existing string variable", d1.sym->name);
	if (d1.sym->type != VAR && d1.sym->type != UNDEF)
		execerror("assignment to non-variable", d1.sym->name);
	if (d1.sym->immutable)
		execerror("illegal reassignment to immutable named constant",
			  d1.sym->name);
	d1.sym->u.val = d2.val;
	d1.sym->type = VAR;
	push(d2);
}

void
addeq(void)
{
	Datum d1, d2;
	d1 = pop();
	d2 = pop();
	if (d1.sym->type != VAR && d1.sym->type != UNDEF)
		execerror("assignment to non-variable",
			d1.sym->name);
	d2.val = d1.sym->u.val += d2.val;
	d1.sym->type = VAR;
	push(d2);
}

void
subeq(void)
{
	Datum d1, d2;
	d1 = pop();
	d2 = pop();
	if (d1.sym->type != VAR && d1.sym->type != UNDEF)
		execerror("assignment to non-variable",
			d1.sym->name);
	d2.val = d1.sym->u.val -= d2.val;
	d1.sym->type = VAR;
	push(d2);
}

void
muleq(void)
{
	Datum d1, d2;
	d1 = pop();
	d2 = pop();
	if (d1.sym->type != VAR && d1.sym->type != UNDEF)
		execerror("assignment to non-variable",
			d1.sym->name);
	d2.val = d1.sym->u.val *= d2.val;
	d1.sym->type = VAR;
	push(d2);
}

void
diveq(void)
{
	Datum d1, d2;
	d1 = pop();
	d2 = pop();
	if (d1.sym->type != VAR && d1.sym->type != UNDEF)
		execerror("assignment to non-variable",
			d1.sym->name);
	d2.val = d1.sym->u.val /= d2.val;
	d1.sym->type = VAR;
	push(d2);
}

void
modeq(void)
{
	Datum d1, d2;
	long x;
	d1 = pop();
	d2 = pop();
	if (d1.sym->type != VAR && d1.sym->type != UNDEF)
		execerror("assignment to non-variable",
			d1.sym->name);
	/* d2.val = d1.sym->u.val %= d2.val; */
	x = (long)d1.sym->u.val;
	x %= (long) d2.val;
	d2.val = d1.sym->u.val = x;
	d1.sym->type = VAR;
	push(d2);
}

void
printtop(void)	/* pop top value from stack, print it */
{
	Datum d;
	static Symbol *s;	/* last value computed */

	if (s == (Symbol*)NULL)		/* first time only */
	{
		s = install("_", VAR, 0.0);
		s->type = VAR;
		make_immutable(s);  /* to prevent user reassignment */
	}
	d = pop();
	prnum(d.val);
	prtext("\n");
	s->u.val = d.val;
}

void
printtopstring(void)	/* pop top string value from stack, print it */
{
	Datum d;
	static Symbol *s;		/* last value computed */
	if (s == (Symbol*)NULL)		/* first time only */
	{
		s = install("__", VAR, 0.0);
		s->type = STRVAR;
		make_immutable(s);  /* to prevent user reassignment */
	}
	d = pop();
	prtext(d.str);
	prtext("\n");
	(void)set_string(s, d.str);
}

void
prexpr(void)	/* print numeric value (with following space) */
{
	Datum d;
	d = pop();
	prnum(d.val);
	prtext(" ");
}

void
prnl(void)
{
	prtext("\n");
}

void
prnum(fp_t x)
{
	prtext(fmtnum(x));
}

void
prstr(void)		/* print string value */
{
	Datum d;
	d = pop();
	prtext(d.str);
}

void
prtext(const char *s)
{	/* print s to stdout, and optionally, to fplog */
	prtext2(s,0);
}

void
prtext2(const char *s, int min_width)
{	/* print s to stdout, and optionally, to fplog, left-adjusted in a
	field of minimum width min_width */

	static int prefix_pending = 1;

	if (s != (const char*)NULL)
	{
		(void)printf("%-*s", min_width, s);
		if (logfile_enabled && (fplog != (FILE*)NULL))
		{
			(void)fprintf(fplog, "%s%-*s",
				      (prefix_pending ? "#-> " : ""), min_width, s);
			prefix_pending = (strchr(s,'\0')[-1] == '\n');
		}
	}
}

void
varread(void)	/* read into variable */
{
	Datum d;
	Symbol *var = (Symbol *) *pc++;
	int c;

	/* Lookahead past space to see whether we have a string or a number */
	for (c = getc(fin); isspace(c); c = getc(fin))
		/* NO-OP */;
	(void)ungetc(c,fin);

	if (c == '"')			/* expect "quoted string" */
	{
		if (var->type == VAR)	/* perhaps we will rescind this restriction in the future */
			execerror("illegal assignment of string to existing numeric variable", var->name);
		if (var->type != STRVAR && var->type != UNDEF)
			execerror("assignment to non-variable", var->name);

		(void)getc(fin);	/* discard the opening quote */
		clearerr(fin);		/* needed to clear eof flag! */
		(void)update_string(var->name, yygetstr());
		d.val = (fp_t)(!feof(fin));
	}
	else if (IsIdStart(c))			/* expect variable */
	{
		Symbol *s;

		s = yygetid();

		if (var->type != STRVAR && var->type != VAR && var->type != UNDEF)
			execerror("assignment to non-variable", var->name);

		if (s->type != STRVAR && s->type != VAR)
			execerror("assignment from non-variable", s->name);

		if (var->type == UNDEF)		/* creating new symbol */
			var->type = s->type;

		/* perhaps we will rescind this restriction in the future */
		if (var->type == VAR && s->type == STRVAR)
			execerror("illegal assignment of string to existing numeric variable", var->name);
		else if (var->type == STRVAR && s->type == VAR)
			execerror("illegal assignment of number to existing string variable", var->name);

		if (var->type == VAR)
			(void)update_number(var->name, s->u.val);
		else if (var->type == STRVAR)
			(void)update_string(var->name, s->u.str);
		else
			execerror("internal type confusion in read() of", var->name);
		d.val = (fp_t)(!feof(fin));
	}
	else				/* expect number */
	{
		fp_t v;
		if (var->type == STRVAR)	/* perhaps we will rescind this restriction in the future */
			execerror("illegal assignment of number to existing string variable", var->name);
		if (var->type != VAR && var->type != UNDEF)
			execerror("assignment to non-variable", var->name);

	  Again:
		switch (fscanf(fin, "%lf", &v)) {
		case EOF:
			if (moreinput())
				goto Again;
			d.val = v = 0.0;
			break;
		case 0:
			execerror("non-number read into", var->name);
			break;
		default:
			d.val = 1.0;
			break;
		}
		(void)update_number(var->name, v);
	}
	push(d);
}

Inst*
code(Inst f)	/* install one instruction or operand */
{
	Inst *oprogp = progp;
	if (progp >= &prog[MAX_PROG])
		execerror("program too big", (const char*)NULL);
	*progp++ = f;
	return oprogp;
}

void
const_assign(void)
{
	Datum d;

	d = pop();
	push(d);
	assign();
	make_immutable(d.sym);	    /* to prevent user reassignment */
}

void
execute(Inst* p)
{
	for (pc = p; *pc != STOP && !returning; )
		(*((++pc)[-1]))();
}

void
const_str_push(void)
{
	Datum d;
	d.str = ((Symbol *)*pc++)->u.str;
	push(d);
}

void
const_str_assign(void)
{
	Datum d;

	d = pop();
	push(d);
	str_assign();
	make_immutable(d.sym);	    /* to prevent user reassignment */
}

void
str_assign(void)
{
	Datum d1, d2;
	d1 = pop();
	d2 = pop();
	if (d1.sym->type == VAR)	/* perhaps we will rescind this restriction in the future */
		execerror("illegal assignment of string to existing numeric variable", d1.sym->name);
	if (d1.sym->type != STRVAR && d1.sym->type != UNDEF)
		execerror("assignment to non-variable", d1.sym->name);
	if (d1.sym->immutable)
		execerror("illegal reassignment to immutable named constant",
			  d1.sym->name);
	(void)set_string(d1.sym, d2.str);
	d1.sym->type = STRVAR;
	push(d2);
}

void
str_concat_nn(void)		/* concatenate two numbers (as strings) */
{
	Datum d1, d2, d3;
	char nbuf1[50];			/* large enough for quad precision result */
	char nbuf2[50];			/* large enough for quad precision result */

	d2 = pop();
	d1 = pop();

	(void)strcpy(nbuf1, fmtnum(d1.val));
	(void)strcpy(nbuf2, fmtnum(d2.val));

	d3.str = concat2(nbuf1,nbuf2);
	push(d3);
}

void
str_concat_ns(void)		/* concatenate number (as string) and strings on stack */
{
	Datum d1, d2, d3;

	d2 = pop();
	d1 = pop();
	d3.str = concat2(fmtnum(d1.val), d2.str);
	push(d3);
}

void
str_concat_sn(void)		/* concatenate string and number (as string) on stack */
{
	Datum d1, d2, d3;

	d2 = pop();
	d1 = pop();
	d3.str = concat2(d1.str, fmtnum(d2.val));
	push(d3);
}

void
str_concat_ss(void)		/* concatenate strings on stack */
{
	Datum d1, d2, d3;

	d2 = pop();
	d1 = pop();

#if 0
	if ((d1.sym->type != STRING) && (d2.sym->type != STRING))
		execerror("attempt to concatenate nonstrings", (const char*)NULL);
#endif

	d3.str = concat2(d1.str, d2.str);
	push(d3);
}

void
str_eq(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

	d1.val = (fp_t)(strcmp(d1.str,d2.str) == 0);
	push(d1);
}

void
str_ge(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

	d1.val = (fp_t)(strcmp(d1.str,d2.str) >= 0);
	push(d1);
}

void
str_gt(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

	d1.val = (fp_t)(strcmp(d1.str,d2.str) > 0);
	push(d1);
}

void
str_index(void)
{	/* return 1-based index of substring in string, or 0 if not found */
	Datum d1, d2, d3;
	const char *p;

	d2 = pop();			/* substring */
	d1 = pop();			/* source string */
	p = (const char*)strstr(d1.str, d2.str);
	d3.val = (fp_t)((p == (const char*)NULL) ? 0 : ((p - d1.str) + 1));
	push(d3);
}

void
str_le(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

	d1.val = (fp_t)(strcmp(d1.str,d2.str) <= 0);
	push(d1);
}

void
str_length(void)
{
	Datum d1, d2;

	d1 = pop();			/* source string */

	d2.val = (fp_t)strlen(d1.str);
	push(d2);
}

void
str_lt(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

	d1.val = (fp_t)(strcmp(d1.str,d2.str) < 0);
	push(d1);
}

void
str_ne(void)
{
	Datum d1, d2;
	d2 = pop();
	d1 = pop();

	d1.val = (fp_t)(strcmp(d1.str,d2.str) != 0);
	push(d1);
}

void
str_strftime(void)	/* convert fmt,time on stack to formatted time string */
{
	Datum d1, d2, d3;
	d2 = pop();			/* time in seconds */
	d1 = pop();			/* format */
	d3.str = dupstr(Strftime(d1.str, d2.val));
	push(d3);
}

void
str_substr(void)
{		/* extract (string,first,length) to new substring, with 1-based indexing */
	Datum d1, d2, d3;
	size_t first;
	size_t len_sub;
	size_t len_str;

	d3 = pop();			/* final index */
	d2 = pop();			/* initial index */
	d1 = pop();			/* source string */

	len_str = strlen(d1.str);
	len_sub = (d3.val <= 0.0) ? (size_t)0 : (size_t)d3.val;

	first = ((d2.val <= 1.0) ? 1 : (size_t)d2.val) - (size_t)1; /* C/C++ 0-based index */

	if (first > len_str)
		first = len_str;	/* index of final NUL */

	if ((first + len_sub) > len_str)
		len_sub = len_str - first;

	if (len_str > 0)
	{
	    	char *p;

		p = (char*)emalloc((len_sub + 1)*sizeof(char));
		(void)strncpy(p,&d1.str[first],len_sub);
		p[len_sub] = '\0';
		d3.str = (const char*)p;
	}
	else
		d3.str = dupstr("");
	push(d3);
}

void
str_to_num(void)
{
	Datum d1, d2;

	d1 = pop();			/* source string */
	d2.val = strton(d1.str, (char**)NULL);
	
	push(d2);
}

void
strbltin0(void)
{

	Datum d;
	d.str = ((SF0_t)*pc++)();
	push(d);
}

void
strbltin1(void)
{

	Datum d;
	d = pop();
	d.str = ((SF1_t)*pc++)(d.str);
	push(d);
}

void
strbltin2(void)
{

	Datum d1, d2;
	d2 = pop();
	d1 = pop();
	d1.str = ((SF2_t)*pc++)(d1.str, d2.str);
	push(d1);
}

void
streval(void)		/* evaluate string variable on stack */
{
	Datum d;
	d = pop();
	if (d.sym->type != STRVAR)
		execerror("attempt to evaluate nonstring variable", d.sym->name);
	d.str = d.sym->u.str;
	push(d);
}

const char *
Who(const char *prefix)
{
	dump_syms(prefix);
	return ("");
}
