#include "config.h"

#if defined(HAVE_STDLIB_H)
#include <stdlib.h>			/* for size_t */
#endif

/* Set dimensions that are fixed at compile time, but whose default
   values may be overridden by compile-time -DMAX_xxx=nnn options.
   Some of these have documented minimum values (see hoc.1) which must
   be enforced here.  All are made available for user inspection in
   __MAX_xxx__ predefined constants. */

#include "fp_t.h"

#if !defined(MAX_NAME)
#define MAX_NAME	1024
#endif
#if (MAX_NAME + 0) < 63			/* avoid silly small values */
#undef MAX_NAME
#define MAX_NAME	63
#endif

#if !defined(MAX_STRING)
#define MAX_STRING	32767
#endif
#if (MAX_STRING + 0) < 1024		/* avoid silly small values */
#undef MAX_STRING
#define MAX_STRING	1024
#endif

#if defined(__cplusplus) || defined(c_plusplus)
#define EXTERN extern "C"
#else
#define EXTERN extern
#endif

typedef fp_t (*F0_t) ARGS((void));
typedef fp_t (*F1_t) ARGS((fp_t));
typedef fp_t (*F2_t) ARGS((fp_t,fp_t));
typedef const char *(*SF0_t) ARGS((void));
typedef const char *(*SF1_t) ARGS((const char *));
typedef const char *(*SF2_t) ARGS((const char *, const char *));

typedef void (*Inst) ARGS((void));
#define	STOP	((Inst) NULL)

#if defined(HAVE_LONG_LONG)
typedef long long LONG_LONG;
typedef unsigned long long UNSIGNED_LONG_LONG;
#else
typedef long LONG_LONG;
typedef unsigned long UNSIGNED_LONG_LONG;
#endif

typedef struct Symbol {	/* symbol table entry */
	union {
		fp_t	val;		/* VAR */
#if 0
		fp_t	(*ptr0) ARGS((void));	/* BLTIN0 */
		fp_t	(*ptr1) ARGS((fp_t));	/* BLTIN1 */
		fp_t	(*ptr2) ARGS((fp_t,fp_t));	/* BLTIN2 */
#else
		F0_t ptr0;	/* BLTIN0 */
		F1_t ptr1;	/* BLTIN1 */
		F2_t ptr2;	/* BLTIN2 */
		SF0_t sptr0;	/* STRBLTIN0 */
		SF1_t sptr1;	/* STRBLTIN1 */
		SF2_t sptr2;	/* STRBLTIN2 */
#endif

		Inst	*defn;		/* FUNCTION, PROCEDURE */
		const char *str;	/* STRING */
	} u;
	const char	*name;
	long	type;
	long	immutable;
	struct Symbol	*next;	/* to link to another */
} Symbol;

Symbol	*install ARGS((const char *, int, fp_t));
Symbol	*lookup ARGS((const char *));

typedef union Datum {	/* interpreter stack type */
	fp_t	val;
	const char *str;
	Symbol	*sym;
} Datum;

typedef union DoubleParts { /* access to floating-point bits as integers */
	fp_t v;
	unsigned int i[2];
} DoubleParts;

/* 1989 and 1999 Standard C, and 1998 Standard C++, require that the
ctype.h isxxx() feature to be functions, so we should be able to
redefine macros to call the parenthesized functions, without changing
any code below.  Unfortunately Apple Darwin botches things, and
defines only isxxx() macros.  Thus, we need our own private names for
these character classifiers.

It is CRITICAL that, before making the range checks, we first convert
c to an unsigned value in 0..255, because most UNIX C and C++
compilers treat char as signed in -128..+127.  Lack of the UC()
wrapper was a nasty bug that took me some time to track down. */

#define UC(c)	( (int)(unsigned char)(c) )
#define UL(x)	( (unsigned long)(x) )
#define IsAlNum(c) (isalnum(c) || ((160 <= UC(c)) && (UC(c) <= 255)))
#define IsAlpha(c) (isalpha(c) || ((160 <= UC(c)) && (UC(c) <= 255)))
#define IsIdStart(c) (IsAlpha(c) || ((c) == '_'))
#define IsIdMiddle(c) (IsAlNum(c) || ((c) == '_'))

extern const char *	progname;

extern	fp_t Fgetd ARGS((int));
extern	int moreinput ARGS((void));
extern	void define ARGS((Symbol *));
extern	void initcode ARGS((void)), xpop ARGS((void)), constpush ARGS((void));
extern	void varpush ARGS((void));
extern	void eval ARGS((void)), add ARGS((void)), sub ARGS((void)), mul ARGS((void)), divop ARGS((void)), mod ARGS((void));
extern	void negate ARGS((void)), power ARGS((void));
extern	void addeq ARGS((void)), subeq ARGS((void)), muleq ARGS((void)), diveq ARGS((void)), modeq ARGS((void));

extern	Inst *progp, *progbase, prog[], *code ARGS((Inst));
extern	void assign ARGS((void)), varread ARGS((void));
extern	void prexpr ARGS((void)), prnl ARGS((void)), prstr ARGS((void));
extern	void gt ARGS((void)), lt ARGS((void)), eq ARGS((void)), ge ARGS((void)), le ARGS((void)), ne ARGS((void));
extern	void And ARGS((void)), Or ARGS((void)), Not ARGS((void));
extern	void ifcode ARGS((void)), whilecode ARGS((void)), forcode ARGS((void));
extern	void call ARGS((void)), arg ARGS((void)), argassign ARGS((void));
extern	void funcret ARGS((void)), procret ARGS((void));
extern	void preinc ARGS((void)), predec ARGS((void)), postinc ARGS((void)), postdec ARGS((void));
extern	void argaddeq ARGS((void)), argsubeq ARGS((void)), argmuleq ARGS((void));
extern	void argdiveq ARGS((void)), argmodeq ARGS((void));
extern	void execute ARGS((Inst*));
extern	void init_builtins ARGS((void));
extern	void printtop ARGS((void));
extern	void run ARGS((void));
extern	int yyparse ARGS((void));
extern	void execerror ARGS((const char *, const char *));
extern	void efree ARGS((void *));
extern	void *emalloc ARGS((size_t));

/* Mathematical, numeric, and support functions in extended hoc */

extern fp_t	Abort ARGS((const char *));
extern fp_t	Abs ARGS((fp_t));
extern fp_t	Acos ARGS((fp_t));
extern fp_t	Acosh ARGS((fp_t));
extern fp_t	Asin ARGS((fp_t));
extern fp_t	Asinh ARGS((fp_t));
extern fp_t	Atan ARGS((fp_t));
extern fp_t	Atanh ARGS((fp_t));
extern fp_t	Cbrt ARGS((fp_t));
extern fp_t	Ceil ARGS((fp_t));
extern fp_t	Copysign ARGS((fp_t, fp_t));
extern fp_t	Cos ARGS((fp_t));
extern fp_t	Cosh ARGS((fp_t));
extern fp_t	CPULimit ARGS((fp_t));
extern fp_t	Erf ARGS((fp_t));
extern fp_t	Erfc ARGS((fp_t));
extern fp_t	Exp ARGS((fp_t));
extern fp_t	Expm1 ARGS((fp_t));
extern fp_t	Exponent ARGS((fp_t));
extern fp_t	Floor ARGS((fp_t));
extern fp_t	Fmod ARGS((fp_t, fp_t));
extern fp_t	Gamma ARGS((fp_t));
extern fp_t	Hypot ARGS((fp_t, fp_t));
extern fp_t	Ilogb ARGS((fp_t));
extern fp_t	Infinity ARGS((void));
extern fp_t	Integer ARGS((fp_t));
extern fp_t	IsFinite ARGS((fp_t));
extern fp_t	IsInf ARGS((fp_t));
extern fp_t	IsNaN ARGS((fp_t));
extern fp_t	IsNormal ARGS((fp_t));
extern fp_t	IsQNaN ARGS((fp_t));
extern fp_t	IsSNaN ARGS((fp_t));
extern fp_t	IsSubnormal ARGS((fp_t));
extern fp_t	J0 ARGS((fp_t));
extern fp_t	J1 ARGS((fp_t));
extern fp_t	Jn ARGS((fp_t, fp_t));
extern fp_t	Ldexp ARGS((fp_t, fp_t));
extern fp_t	Lgamma ARGS((fp_t));
extern fp_t	Log ARGS((fp_t));
extern fp_t	Log10 ARGS((fp_t));
extern fp_t	Log1p ARGS((fp_t));
extern fp_t	Log2 ARGS((fp_t));
extern fp_t	Macheps ARGS((fp_t));
extern fp_t	MaxNormal ARGS((void));
extern fp_t	MinNormal ARGS((void));
extern fp_t	MinSubnormal ARGS((void));
extern fp_t	NaN ARGS((void));
extern fp_t	Nearest ARGS((fp_t, fp_t));
extern fp_t	Nextafter ARGS((fp_t, fp_t));
extern fp_t	Nint ARGS((fp_t));
extern fp_t	Pow ARGS((fp_t, fp_t));
extern fp_t	QNaN ARGS((void));
extern fp_t	Remainder ARGS((fp_t, fp_t));
extern fp_t	Rand ARGS((void));
extern fp_t	RandInt ARGS((fp_t, fp_t));
extern fp_t	Randl ARGS((fp_t));
extern fp_t	Rint ARGS((fp_t));
extern fp_t	Rsqrt ARGS((fp_t));
extern fp_t	Scalb ARGS((fp_t, fp_t));
extern fp_t	Second ARGS((void));
extern fp_t	SetRandSeed ARGS((fp_t));
extern fp_t	Significand ARGS((fp_t));
extern fp_t	Sin ARGS((fp_t));
extern fp_t	Sinh ARGS((fp_t));
extern fp_t	SNaN ARGS((void));
extern fp_t	Sqrt ARGS((fp_t));
extern fp_t	Systime ARGS((void));
extern fp_t	Tan ARGS((fp_t));
extern fp_t	Tanh ARGS((fp_t));
extern fp_t	Trunc ARGS((fp_t));
extern fp_t	Y0 ARGS((fp_t));
extern fp_t	Y1 ARGS((fp_t));
extern fp_t	Yn ARGS((fp_t, fp_t));

extern int	IsBigEndian ARGS((void));
extern int	default_precision ARGS((void));
extern int	get_precision ARGS((void));
extern int	is_hidden ARGS((const char *, const char *));
extern int	is_match ARGS((const char *, const char *));
extern int	set_precision ARGS((int));

extern fp_t	store ARGS((fp_t));

extern Symbol	*install_const_number ARGS((const char *, fp_t));
extern Symbol	*install_const_string ARGS((const char *, const char *));
extern Symbol	*install_number ARGS((const char *, fp_t));
extern Symbol	*install_string ARGS((const char *, const char *));
extern Symbol	*set_number ARGS((Symbol *, fp_t));
extern Symbol	*set_string ARGS((Symbol *, const char *));
extern Symbol	*update_number ARGS((const char *, fp_t));
extern Symbol	*update_string ARGS((const char *, const char *));

extern const char * concat2 ARGS((const char *, const char *));
extern const char * concat3 ARGS((const char *, const char *, const char *));
extern const char * concat4 ARGS((const char *, const char *, const char *, const char *));
extern const char * concat5 ARGS((const char *, const char *, const char *, const char *, const char *));
extern const char * dupstr ARGS((const char *));
extern const char * Evalcommands ARGS((const char *));
extern const char * fmtnum ARGS((fp_t));
extern const char * Getenv ARGS((const char *));
extern const char * Inf_string ARGS((fp_t));
extern const char * Load ARGS((const char *));
extern const char * Logfile ARGS((const char *));
extern const char * Logoff ARGS((void));
extern const char * Logon ARGS((void));
extern const char * NaN_string ARGS((fp_t));
extern const char * Now ARGS((void));
extern const char * Printenv ARGS((const char *));
extern const char * Putenv ARGS((const char *, const char *));
extern const char * Save ARGS((const char *, const char *));
extern const char * Strftime ARGS((const char *, fp_t));
extern const char * Tolower ARGS((const char *));
extern const char * Toupper ARGS((const char *));
extern const char * Who ARGS((const char *));

extern const char * first_matching_symbol_name ARGS((const char *));
extern const char * first_symbol_name ARGS((void));
extern const char * first_symbol_pname ARGS((void));
extern const char * msg_translate ARGS((const char *));
extern const char * next_matching_symbol_name ARGS((const char *));
extern const char * next_symbol_name ARGS((void));
extern const char * next_symbol_pname ARGS((void));
extern const char * xdbltos ARGS((fp_t));
extern const char * xinttos ARGS((fp_t));
extern fp_t	    strton ARGS((const char *, char **));
extern fp_t	    xstrtod ARGS((const char *, char **));
extern int	    decval ARGS((int));
extern int	    hexval ARGS((int));

extern Symbol *	first_symbol ARGS((void));
extern Symbol *	next_symbol ARGS((void));

extern void	abort_user ARGS((void));
extern void	bltin0 ARGS((void));
extern void	bltin1 ARGS((void));
extern void	bltin2 ARGS((void));
extern void	const_assign ARGS((void));
extern void	const_str_assign ARGS((void));
extern void	const_str_push ARGS((void));
extern void	dump_syms ARGS((const char *));
extern void	hex ARGS((void));
extern void	hexfp ARGS((void));
extern void	hexint ARGS((void));
extern void	make_immutable ARGS((Symbol *));
extern void	noop ARGS((void));
extern void	numtostr ARGS((void));
extern void	printtopstring ARGS((void));
extern void	prnum ARGS((fp_t));
extern void	prtext ARGS((const char *));
extern void	prtext2 ARGS((const char *, int));
extern void	set_filename ARGS((const char *));
extern void	str_assign ARGS((void));
extern void	str_concat_nn ARGS((void));
extern void	str_concat_ns ARGS((void));
extern void	str_concat_sn ARGS((void));
extern void	str_concat_ss ARGS((void));
extern void	str_eq ARGS((void));
extern void	str_ge ARGS((void));
extern void	str_gt ARGS((void));
extern void	str_index ARGS((void));
extern void	str_le ARGS((void));
extern void	str_length ARGS((void));
extern void	str_lt ARGS((void));
extern void	str_ne ARGS((void));
extern void	str_strftime ARGS((void));
extern void	str_substr ARGS((void));
extern void	str_to_num ARGS((void));
extern void	strbltin0 ARGS((void));
extern void	strbltin1 ARGS((void));
extern void	strbltin2 ARGS((void));
extern void	streval ARGS((void));

#if defined(__LCC__)
/* Prototypes for all of the UNIX extensions that are absent from ISO
   1989 Standard C are omitted from lcc's header files, even though they
   are present in the runtime library. */
extern double acosh ARGS((double));
extern double asinh ARGS((double));
extern double atanh ARGS((double));
extern double cbrt ARGS((double));
extern double copysign ARGS((double, double));
extern double erf ARGS((double));
extern double erfc ARGS((double));
extern double expm1 ARGS((double));
extern double hypot ARGS((double, double));
extern double j0 ARGS((double));
extern double j1 ARGS((double));
extern double jn ARGS((int, double));
extern double lgamma ARGS((double));
extern double log1p ARGS((double));
extern double nextafter ARGS((double, double));
extern double remainder ARGS((double, double));
extern double rint ARGS((double));
extern double scalb ARGS((double, double));
extern double significand ARGS((double));
extern double y0 ARGS((double));
extern double y1 ARGS((double));
extern double yn ARGS((int, double));
#endif

#if defined(__PGI) || defined(__LCC__)
#define HAVE_NAN_BOTCH
#endif
