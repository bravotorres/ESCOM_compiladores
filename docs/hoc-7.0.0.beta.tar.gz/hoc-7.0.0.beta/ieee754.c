#include "hoc.h"

#if defined(HAVE_FLOAT_H)
#include <float.h>
#endif

#if defined(HAVE_MATH_H)
#include <math.h>
#endif

#if defined(DEBUG_MACHEPS)
#if defined(HAVE_STDIO_H)
#include <stdio.h>
#endif
#endif


/* These functions are in -lm, but are missing from math.h, sigh... */
EXTERN fp_t trunc ARGS((fp_t));		/* all GNU/Linux */
EXTERN int ilogb ARGS((fp_t));		/* Compaq/DEC OSF/1 */
#if defined(HAVE_NEAREST)
EXTERN fp_t nearest ARGS((fp_t,fp_t));	/* Compaq/DEC OSF/1 */
#endif

#define TWOTO52	4503599627370496.0	/* 2^52 */

fp_t
Ceil(fp_t x)
{
	fp_t y;

	/* TO DO: Should Ceil(-Infinity) return a finite number or
	not? Sun's returns ceil(Infinity) as 2^63, and ceil(-Infinity)
	as -2^63, which both seem inconsistent. */

	if (IsNaN(x))
		return (x);
	else if (IsInf(x))
		return (x);

#if defined(HAVE_CEIL)
	y = ceil(x);
#else
	y = (fp_t)((LONG_LONG)(x));
	if (x > y)
		y++;
#endif
	return (y);
}

fp_t
Copysign(fp_t x, fp_t y)
{
#if defined(HAVE_COPYSIGN)
	return (copysign(x,y));
#else
	execerror("copysign(x,y) is not available on this system", (const char*)NULL);
	return (0.0);			/* NOT REACHED */
#endif
}

fp_t
Exponent(fp_t x)
{	/* Return the unbiased base-2 exponent of x */
#if defined(HAVE_IEEE_754)
	DoubleParts d;
	fp_t xabs;
	int big_endian = IsBigEndian();
	int offset;

	xabs = (x < 0) ? -x : x;

	if (xabs < MinNormal())
	{
		offset = -52;
		x *= TWOTO52;
	}
	else
		offset = 0;

	d.v = x;

	return ((fp_t)(((d.i[1-big_endian] & UL(0x7ff00000)) >> 20)) - 1023 + offset);
#else
	return ((fp_t)Nint(Log2(x))); /* TO DO: implement efficiently for non-IEEE 754 systems */
#endif
}

fp_t
Floor(fp_t x)
{
	fp_t y;

	/* TO DO: Should Floor(-Infinity) return a finite number or
	not? Sun's returns floor(Infinity) as 2^63, and floor(-Infinity)
	as -2^63, which both seem inconsistent. */

	if (IsNaN(x))
		return (x);
	else if (IsInf(x))
		return (x);

#if defined(HAVE_FLOOR)
	y = floor(x);
#else
	y = (fp_t)((LONG_LONG)(x));
	if (x < y)
		y--;
#endif
	return (y);
}

fp_t
Fmod(fp_t x, fp_t y)
{
#if defined(HAVE_FMOD)
	return (fmod(x,y));
#else
	execerror("fmod(x,y) is not available on this system", (const char*)NULL);
	return (0.0);			/* NOT REACHED */
#endif
}

fp_t
Ilogb(fp_t x)
{
#if defined(HAVE_ILOGB)
	return ((fp_t)ilogb(x));
#else
	return ((fp_t)(int)Log2(x));
#endif
}

fp_t
Infinity(void)
{
	static fp_t infinity = 0.0;

	if (infinity == 0.0)	/* normally happens only on first call */
	{
#if defined(HAVE_IEEE_754)
		infinity = store(1.0) / store(0.0);
#elif defined(DBL_MAX)
		infinity = DBL_MAX;
#else
		execerror("Infinity() is not available on this system",
			  (const char*)NULL);
#endif
	}
	return (infinity);
}

fp_t
Integer(fp_t x)
{
#if 0
	return (fp_t)(long)x;
#else
	/* Since all numbers are represented as type fp_t, we can
	provided a wider range of integers than long provides: */
	if (IsNaN(x))
	{
		execerror("int(NaN) is undefined", (const char*)NULL);
		return (0.0);		/* NOT REACHED */
	}
	else if (x < 0.0)
		return (Ceil(x));
	else /* (x >= 0.0) */
		return (Floor(x));
#endif
}

int
IsBigEndian(void)
{
	DoubleParts d;
	d.v = 1.0;
	return ((d.i[0] != 0) ? 1 : 0);
}

fp_t
IsFinite(fp_t x)
{
	return ((fp_t)(!IsNaN(x) && !IsInf(x)));
}

fp_t
IsInf(fp_t x)
{
	/* This portable implementation that does not require IEEE 754
	   arithmetic to function properly is due to Norman
	   L. Schryer, and used in his FPTEST package.  See ``A Test
	   of a Computer's Floating-Point Arithmetic Unit'', Bell
	   Laboratories Computing Science Technical Report no. 89,
	   February 4, 1981.  Available, with the software (under
	   license), at http://www.bell-labs.com/project/fptest/ */

#if defined(HAVE_NAN_BOTCH)		/* see IsNaN() for why */
	if (IsNaN(x))
		return (0.0);
#endif

	if (x < 0.0)
		x = -x;			/* force positive */
	if (x < 1.0)			/* small, so finite */
		return (0.0);
	else if ((x / 2.0) == x)	/* only Inf/2 == Inf */
		return (1.0);
	else				/* must be finite */
		return (0.0);
}

fp_t
IsNaN(fp_t x)
{
#if defined(HAVE_NAN_BOTCH)
	/* The Portland Group compilers, pgcc and pgCC, on Intel x86 */
	/* incorrectly generate a 64-bit integer comparison, instead */
	/* of a floating-point one.  This is wrong for NaNs, so even */
	/* the store() subterfuge does not produce the right answer. */
	/* Therefore, we have to grovel around in the bits.          */
	DoubleParts d;
	int big_endian = IsBigEndian();
	d.v = x;
	return ((fp_t)(((d.i[1-big_endian] & UL(0x7ff00000)) == UL(0x7ff00000)) &&
			 ((d.i[1-big_endian] & UL(~0xfff00000)) ||
			  d.i[big_endian])));
#else
	return ((fp_t)(store(x) != x));	/* should thwart optimizers */
#endif
}

fp_t
IsNormal(fp_t x)
{
	return (fp_t)((IsFinite(x) && !IsSubnormal(x)));
}

/***********************************************************************
The implementation of IsQNaN() is unavoidably system-dependent, and for
two of these architectures, there is only one type of NaN, so for them,
both IsSNaN() and IsQNaN() should be true!

From p. 4-59 of the Alpha AXP Architecture Manual:
	quiet NaN:	initial fraction bit of 1
	signaling NaN:	initial fraction bit of 0
------------------------------------------------------------------------
From p. 21 of SPARC Architecture Manual v8:
[same choice as Alpha]
	quiet NaN:	initial fraction bit of 1
	signaling NaN:	initial fraction bit of 0
------------------------------------------------------------------------
From p. 145 of The PowerPC Architecture:
[same as Alpha and SPARC]
	quiet NaN:	initial fraction bit of 1
	signaling NaN:	initial fraction bit of 0
------------------------------------------------------------------------
From p. 2-5 of i860 Microprocessor Programmer's Reference Manual:
[same as Alpha, SPARC, PowerPC]
	quiet NaN:	initial fraction bit of 1
	signaling NaN:	initial fraction bit of 0
------------------------------------------------------------------------
From p. 2-15 of MC68881 Floating-Point Coprocessor Users Manual:
[same as Alpha, SPARC, PowerPC, Intel i860]
	quiet NaN:	initial fraction bit of 1
	signaling NaN:	initial fraction bit of 0
------------------------------------------------------------------------
From p. 5-3 (sequential 87 of 216) Intel IA-64 Architecture Software
Developer's Manual, Rev 1.0:
[same as Alpha, SPARC, PowerPC, Intel i860, MC68881]
	quiet NaN:	initial fraction bit of 1
	signaling NaN:	initial fraction bit of 0
------------------------------------------------------------------------
From p. 8-7 of PA-RISC 2.0 Architecture:
[opposite of Alpha, SPARC, PowerPC, i860]
	quiet NaN:	initial fraction bit of 0
	signaling NaN:	initial fraction bit of 1
------------------------------------------------------------------------
From p. E-2 of MIPS RISC Architecture:
[no distinction between NaNs]
	NaN:		initial fraction bit of 0
------------------------------------------------------------------------
From Palmer and Morse The 8087 Primer and p. I-25 of iAPX 286
Programmer's Reference Manual:
[no distinction between NaNs]
	NaN:		at least one nonzero fraction bit
Generated NaNs have negative sign bit.

Experiments on Pentium III show 0/0 -> 0xfff80000_00000000, so the
leading fraction bit is the only nonzero generated.  However, this can
be explicitly negated to obtain 0x7ff80000_00000000.
------------------------------------------------------------------------
***********************************************************************/

fp_t
IsQNaN(fp_t x)
{
	if (IsNaN(x))
	{
		DoubleParts d;
		int big_endian = IsBigEndian();

		d.v = x;

#if defined(__alpha)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) != 0));
#elif defined(__sparc)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) != 0));
#elif defined(__i860)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) != 0));
#elif defined(_POWER) || defined(__PPC) || defined(__powerpc)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) != 0));
#elif defined(__ia64)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) != 0));
#elif defined(__hppa)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) == 0));
#elif defined(__i386) || defined(__i486) || defined(__i586) || defined(__i686)
		(void)store(d.v);	/* avoid complaints about unused d */
		return ((fp_t)(big_endian == big_endian)); /* avoids compiler warnings about unused big_endian*/
#elif defined(__mips)
		(void)store(d.v);	/* avoid complaints about unused d */
		return ((fp_t)(big_endian == big_endian)); /* avoids compiler warnings about unused big_endian*/
#else  /* fall back to majority style, which could still be wrong */
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) != 0));
#endif

	}
	else
		return (0.0);
}

fp_t
IsSNaN(fp_t x)
{
	if (IsNaN(x))
	{
		DoubleParts d;
		int big_endian = IsBigEndian();

		d.v = x;

#if defined(__alpha)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) == 0));
#elif defined(__sparc)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) == 0));
#elif defined(__i860)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) == 0));
#elif defined(_POWER) || defined(__PPC) || defined(__powerpc)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) == 0));
#elif defined(__ia64)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) == 0));
#elif defined(__hppa)
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) != 0));
#elif defined(__i386) || defined(__i486) || defined(__i586) || defined(__i686)
		(void)store(d.v);	/* avoid complaints about unused d */
		return ((fp_t)(big_endian == big_endian)); /* avoids compiler warnings about unused big_endian*/
#elif defined(__mips)
		(void)store(d.v);	/* avoid complaints about unused d */
		return ((fp_t)(big_endian == big_endian)); /* avoids compiler warnings about unused big_endian*/
#else  /* fall back to majority style, which could still be wrong */
		return ((fp_t)((d.i[1 - big_endian] & UL(0x00080000)) == 0));
#endif

	}
	else
		return (0.0);
}

fp_t
IsSubnormal(fp_t x)
{
	if (x == 0.0)
		return (0.0);
	else if (IsNaN(x))
		return (0.0);
	else if (IsInf(x))
		return (0.0);
	else
	{
#if defined(HAVE_IEEE_754)
		return ((fp_t)(Exponent(x) <= -1023.0));
#else
		return (0.0);
#endif
	}
}

fp_t
Ldexp(fp_t x, fp_t y)
{
#if defined(HAVE_LDEXP)
	return (ldexp(x,(int)y));
#else
	return (x * pow(2.0,(fp_t)(int)y));
#endif
}

#if defined(DEBUG_MACHEPS)
void
Dump(const char *s, fp_t x)
{
	DoubleParts d;
	int big_endian = IsBigEndian();
	d.v = x;

	fprintf(stderr,"%s: %g\t0x%08x_%08x\n",
		s, d.v, d.i[1-big_endian], d.i[big_endian]);
}
#endif


fp_t
Macheps(fp_t x)
{
	/* Macheps(x) returns the generalized machine epsilon of x,
	   the smallest number which, when added to x, produces a sum
	   that still differs from x: (x + macheps(x)) != x.

	   NB: This code guarantees these results:
		  macheps(Inf)  -> NaN
		  macheps(-Inf) -> NaN
		  macheps(NaN)  -> NaN
		  macheps(-NaN) -> -NaN
	*/

	fp_t epsilon;
	fp_t temp;
	static fp_t macheps_1 = 0.0;

#if !defined(HAVE_NAN_BOTCH)
	if ((x == 1.0) && (macheps_1 != 0.0)) /* handle common case fast */
		return (macheps_1);
#endif

	if (IsNaN(x))
		return (x);

	if (IsInf(x))
		return (NaN());

	if (x == 0.0)
		epsilon = 1.0;
	else
		epsilon = fabs(x);

#if defined(DEBUG_MACHEPS)
	Dump("macheps(): 1: x = ", x);
	Dump("macheps(): 1: epsilon = ", epsilon);
	Dump("macheps(): 1: epsilon/2.0 = ", epsilon/2.0);
#if 1
	temp = store(x + store(epsilon/2.0));
#else
	temp = store(x + epsilon/2.0);
#endif
	Dump("macheps(): 1: temp = ", temp);
	while (store(temp) != x)
	{
		epsilon /= 2.0;
		Dump("macheps(): 2: epsilon = ", epsilon);
#if 1
		temp = store(x + store(epsilon/2.0));
#else
		temp = store(x + epsilon/2.0);
#endif
		Dump("macheps(): 2: temp = ", temp);
	}
#else
	while (store(x + store(epsilon/2.0)) != x)
		epsilon /= 2.0;
#endif

	/* purify epsilon to eliminate all but high-order bit */
	temp = store(x + epsilon);
	if (IsInf(temp))/* x == MAXNORMAL: avoid overflow in purification */
		epsilon = store(x  + store(epsilon - x));
	else
		epsilon = store(temp - x);

	if (x == 1.0)			/* remember common case */
		macheps_1 = epsilon;

	return (epsilon);
}

fp_t
MaxNormal(void)
{
	static fp_t maxnormal = 0.0;

	if (maxnormal == 0.0)	/* normally happens only on first call */
	{

#if defined(HAVE_IEEE_754)
		maxnormal = (2.0*((1.0 - Pow(2.0,-53.0)) * Pow(2.0, 1023.0)));
#elif defined(DBL_MAX)
		maxnormal = DBL_MAX;
#else
		execerror("maximum normal number is not yet programmed in hoc for this system",
			  (const char*)NULL);
#endif

	}
	return (maxnormal);
}

fp_t
MinNormal(void)
{
	static fp_t minnormal = 0.0;

	if (minnormal == 0.0)	/* normally happens only on first call */
	{

#if defined(HAVE_IEEE_754)
		minnormal = Pow(2.0, -1022.0);
#else
		minnormal = Macheps(0.0);
#endif

	}
	return (minnormal);
}

fp_t
MinSubnormal(void)
{
	/* Return the minimimum subnormal number.  If subnormals are
	   not supported, then return the minimim normal number instead. */
	static fp_t minsubnormal = 0.0;

	if (minsubnormal == 0.0)	/* normally happens only on first call */
	{
		/* This code works for IEEE 754 (with or without subnormals),
		   and also non-IEEE 754. */
		minsubnormal = Macheps(0.0);
	}
	return (minsubnormal);
}

fp_t
NaN(void)
{
	static fp_t nan = 0.0;

	if (nan == 0.0)	/* normally happens only on first call */
	{
#if defined(HAVE_IEEE_754)
		nan = store(0.0) / store(0.0);
#else
		/* ISO/IEC 9899:1999(E) Programming languages -- C, Second
		edition 1999-12-01, says in section 7.12.11.2 on p. 236: ``If
		the implementation does not support quiet NaNs, the functions
		[nan(""), nanf(""), nanl("")] return zero.'' */
#endif
	}
	return (nan);
}

fp_t
Nearest(fp_t x, fp_t y)
{
#if defined(HAVE_NEAREST)
	return (nearest(x,y));
#else
	return (Nextafter(x,y));		/* TO BE FIXED: incorrect translation */
#endif
}

fp_t
Nextafter(fp_t x, fp_t y)
{
#if defined(HAVE_NEXTAFTER)
	return (nextafter(x,y));
#else
	if (IsNaN(x))
		return (NaN());
	else if (IsNaN(y))
		return (NaN());
	else if (IsInf(x) && (x > 0.0) && ((y < 0.0) || (y < x)))
		return (MaxNormal());
	else if (IsInf(x) && (x < 0.0) && ((y > 0.0) || (y > x)))
		return (-MaxNormal());
	else if (IsInf(x) && (x == y))
		return (x);
	else if ((x == MaxNormal()) && (x < y))
		return (Infinity());
	else if ((x == -MaxNormal()) && (x > y))
		return (-Infinity());
	else if (x < y)
		return (x + macheps(x));
	else if (x > y)
		return (x - macheps(x)/2.0);
	else /* (x == y) */
		return (x);
#endif
}

fp_t
Nint(fp_t x)
{
	return ((x >= 0.0) ?
		(fp_t)((LONG_LONG)(x + 0.5)) :
		(fp_t)((LONG_LONG)(x - 0.5)));
}

fp_t
QNaN(void)
{
	return (NaN());
}

fp_t
Remainder(fp_t x, fp_t y)
{
#if defined(HAVE_REMAINDER)
	return (remainder(x,y));
#else
	execerror("remainder(x) is not available on this system", (const char*)NULL);
	return (0.0);			/* NOT REACHED */
#endif
}

fp_t
Rint(fp_t x)
{
#if defined(HAVE_RINT)
	return (rint(x));
#else
	execerror("rint(x) is not available on this system", (const char*)NULL);
	return (0.0);			/* NOT REACHED */
#endif
}

fp_t
Scalb(fp_t x, fp_t y)
{
	y = Integer(y);		/* to match documentation in help_scalb() */
				/* and get consistency across platforms */
				/* NB: Use Integer(), not (LONG_LONG)(), to */
				/* handle NaN as documented */
#if defined(HAVE_SCALB)
	return (scalb(x,y));
#else
	return (x * pow(2.0, y));
#endif
}

fp_t
Significand(fp_t x)
{
#if defined(HAVE_SIGNIFICAND)
	return (significand(x));
#else
	/* Scale subnormal numbers into the normal range to avoid
	problems with subnormals in Trunc() and Log2() (e.g.,
	Compaq/DEC Alpha OSF/1 4.0). */

	if (IsNaN(x))
		return (copysign(1.0,x) * NaN());
	else if (IsInf(x))
		return (copysign(1.0,x) * Infinity());
	else if (x == 0.0)
		return (copysign(1.0,x) * 0.0);
	else
	{
		DoubleParts d;
		fp_t xabs;
		int big_endian = IsBigEndian();

		xabs = (x < 0) ? -x : x;
		if (xabs < MinNormal())	/* scale to force normalization */
			x *= TWOTO52;

		d.v = x;
		d.i[1-big_endian] &= UL(0x000fffff);
		d.i[1-big_endian] |= (x < 0.0) ? UL(0xbff00000) : UL(0x3ff00000);
		return (d.v);
	}
#endif
}

fp_t
SNaN(void)
{
	fp_t maybe_NaN = NaN();
	static unsigned int SNaN_count = 0;

	if (IsNaN(maybe_NaN))		/* false on non IEEE 754 systems */
	{
		DoubleParts d;
		int big_endian = IsBigEndian();

		d.v = maybe_NaN;

		/* A NaN must have a nonzero significand, so we
		   choose to create up to 2^32 - 1 unique SNaNs.
		   For the moment, only two are generated by hoc,
		   for the constants SNAN and SNaN. */
		SNaN_count++;
		if (SNaN_count == 0)	/* then counter wrapped */
			SNaN_count++;

		d.i[big_endian] = SNaN_count;

#if defined(__alpha)
		d.i[1 - big_endian] &= UL(~0x00080000);
#elif defined(__sparc)
		d.i[1 - big_endian] &= UL(~0x00080000);
#elif defined(__i860)
		d.i[1 - big_endian] &= UL(~0x00080000);
#elif defined(_POWER) || defined(__PPC) || defined(__powerpc)
		d.i[1 - big_endian] &= UL(~0x00080000);
#elif defined(__ia64)
		d.i[1 - big_endian] &= UL(~0x00080000);
#elif defined(__hppa)
		d.i[1 - big_endian] |=  0x00080000;
#elif defined(__i386) || defined(__i486) || defined(__i586) || defined(__i686)
		(void)store(d.v); /* No signaling NaN in the Intel IA-32 architecture */
#elif defined(__mips)
		(void)store(d.v);      /* No signaling NaN in the MIPS architecture */
#else  /* fall back to majority style, which could still be wrong */
		d.i[1 - big_endian] &= UL(~0x00080000);
#endif
		maybe_NaN = d.v;
	}
	return (maybe_NaN);
}

fp_t
Trunc(fp_t x)
{
#if defined(HAVE_TRUNC)
	return (trunc(x));
#else
	return (Integer(x));
#endif
}
