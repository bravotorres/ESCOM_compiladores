
# line 2 "hoc.y"
#include "hoc.h"

#define __my_yylex			/* for SGI yacc and C++ */

#if defined(YYDEBUG)
extern int yydebug;
#else
#define YYDEBUG 0	/* so this works with byacc, bison, and yacc */
#endif

/* We need larger internal yacc tables to get consistent results across
   platforms for test/long-operand.hoc */
#define YYMAXDEPTH	8000
#define YYSTACKSIZE	8000

#if defined(HAVE_CTYPE_H)
#include <ctype.h>
#endif

#if defined(HAVE_ERRNO_H)
#include <errno.h>
#endif

#if defined(HAVE_LOCALE_H)
#include <locale.h>
#endif

#if defined(HAVE_SETJMP_H)
#include <setjmp.h>
#endif

#if defined(HAVE_SIGNAL_H)
#include <signal.h>
#endif

#if defined(_AIX)
#define yyerror_const 			/* workaround for bugs in AIX yacc output */
#else
#define yyerror_const const
#endif

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" int yylex ARGS((void));
extern "C" void fpecatch ARGS((int dummy));
extern "C" void intcatch ARGS((int dummy));
extern "C" void xcpucatch ARGS((int dummy));
extern "C" void yyerror ARGS((yyerror_const char* s));
#else
int yylex ARGS((void));
void fpecatch ARGS((int dummy));
void intcatch ARGS((int dummy));
void xcpucatch ARGS((int dummy));
void yyerror ARGS((yyerror_const char* s));
#endif

#if defined(HAVE_STDIO_H)
#include <stdio.h>
#endif

#if defined(HAVE_STDLIB_H)
#include <stdlib.h>
#endif

#if defined(HAVE_STRING_H)
#include <string.h>
#endif

#if defined(HAVE_UNISTD_H)
#include <unistd.h>
#endif

#if !defined(R_OK)
#define R_OK 04
#endif

#if !defined(HOCRC)
#define HOCRC	".hocrc"
#endif

#if !defined(SYSHOCDIR)
#define SYSHOCHLP	"/usr/local/share/lib/hoc/hoc-" PACKAGE_VERSION "/"
#endif

#if !defined(SYSHOCHLPBASE)
#define SYSHOCHLPBASE	"help.hoc"
#endif

#if !defined(SYSHOCHLP)
#define SYSHOCHLP SYSHOCDIR "/" SYSHOCHLPBASE
#endif

#if !defined(SYSHOCRCBASE)
#define SYSHOCRCBASE	"hoc.rc"
#endif

#if !defined(SYSHOCRC)
#define SYSHOCRC SYSHOCDIR "/" SYSHOCRCBASE
#endif

#if !defined(SYSHOCXLTBASE)
#define SYSHOCXLTBASE	"translations.hoc"
#endif

#if !defined(SYSHOCXLT)
#define SYSHOCXLT SYSHOCDIR "/" SYSHOCXLTBASE
#endif

#define	code2(c1,c2)		code(c1); (void)code(c2)
#define	code3(c1,c2,c3)		code2(c1,c2); (void)code(c3)
#define	code4(c1,c2,c3,c4)	code3(c1,c2,c3); (void)code(c4)

int			indef;			/* needed in code.c too */
const char *		current_filename;	/* needed in string.c */


static int	c = '\n';		/* global for use by warning() */
static int	infile_count = 0;
static const char *syshocdir = SYSHOCDIR;
static const char *syshochlp = SYSHOCHLP;
static const char *syshochlpbase = SYSHOCHLPBASE;
static const char *syshocrc = SYSHOCRC;
static const char *syshocrcbase = SYSHOCRCBASE;
static const char *syshocxlt = SYSHOCXLT;
static const char *syshocxltbase = SYSHOCXLTBASE;
static const char *hocrc = HOCRC;

int			main ARGS((int, char*[]));
const char *		yygetstr ARGS((void));		/* used in code.c:varread() */
void			set_filename ARGS((const char *)); /* used in string.c:Load() */

static void             author_and_die ARGS((void));
static int		backslash ARGS((int));
static void             bump_lineno ARGS((void));
static void             copyright_and_die ARGS((void));
static void             defnonly ARGS((const char *));
static void             do_init_files ARGS((void));
static void		do_one_init_file ARGS((const char *filename));
static void             do_post_args ARGS((int *, char*[]));
static void             do_pre_args ARGS((const int *, const char*[]));
static int              follow ARGS((int, int, int));
static const char *     get_locale_filename ARGS((const char *, const char *));
static const char *     get_locale_name ARGS((void));
static void             help_and_die ARGS((void));
static void             init_lineno ARGS((void));
static void		init_locale ARGS((void));
static void		init_readline ARGS((void));
static void             show ARGS((const char *[]));
static void             usage ARGS((void));
static void             usage_and_die ARGS((const char *));
static void             version_and_die ARGS((void));
static void             warning ARGS((const char *, const char *));


# line 155 "hoc.y"
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
	Symbol	*sym;	/* symbol table pointer */
	Inst	*inst;	/* machine instruction */
	long	narg;	/* number of arguments */
} YYSTYPE;
# define NUMBER 257
# define STRING 258
# define PRINT 259
# define VAR 260
# define UNDEF 261
# define WHILE 262
# define FOR 263
# define IF 264
# define ELSE 265
# define FUNCTION 266
# define PROCEDURE 267
# define RETURN 268
# define FUNC 269
# define PROC 270
# define READ 271
# define ABORT 272
# define BLTIN0 273
# define BLTIN1 274
# define BLTIN2 275
# define HEX 276
# define HEXFP 277
# define HEXINT 278
# define INDEX 279
# define LENGTH 280
# define NUMTOSTR 281
# define PRINTF 282
# define PRINTLN 283
# define STRBLTIN0 284
# define STRBLTIN1 285
# define STRBLTIN2 286
# define STRVAR 287
# define STRFTIME 288
# define STRTONUM 289
# define SUBSTR 290
# define ARG 291
# define ADDEQ 292
# define SUBEQ 293
# define MULEQ 294
# define DIVEQ 295
# define MODEQ 296
# define CONSTEQ 297
# define OR 298
# define AND 299
# define GT 300
# define GE 301
# define LT 302
# define LE 303
# define EQ 304
# define NE 305
# define UNARYMINUS 306
# define UNARYPLUS 307
# define NOT 308
# define INC 309
# define DEC 310

#include <inttypes.h>

#ifdef __STDC__
#include <stdlib.h>
#include <string.h>
#define	YYCONST	const
#else
#include <malloc.h>
#include <memory.h>
#define	YYCONST
#endif

#include <values.h>

#if defined(__cplusplus) || defined(__STDC__)

#if defined(__cplusplus) && defined(__EXTERN_C__)
extern "C" {
#endif
#ifndef yyerror
#if defined(__cplusplus)
	void yyerror(YYCONST char *);
#endif
#endif
#ifndef yylex
	int yylex(void);
#endif
	int yyparse(void);
#if defined(__cplusplus) && defined(__EXTERN_C__)
}
#endif

#endif

#define yyclearin yychar = -1
#define yyerrok yyerrflag = 0
extern int yychar;
extern int yyerrflag;
YYSTYPE yylval;
YYSTYPE yyval;
typedef int yytabelem;
#ifndef YYMAXDEPTH
#define YYMAXDEPTH 150
#endif
#if YYMAXDEPTH > 0
int yy_yys[YYMAXDEPTH], *yys = yy_yys;
YYSTYPE yy_yyv[YYMAXDEPTH], *yyv = yy_yyv;
#else	/* user does initial allocation */
int *yys;
YYSTYPE *yyv;
#endif
static int yymaxdepth = YYMAXDEPTH;
# define YYERRCODE 256

# line 357 "hoc.y"

	/* end of grammar */

#include "readline.h"

#undef getc
#define getc(fpin)			irl_getchar(fpin)
#undef ungetc
#define ungetc(c,fpin)			irl_unget_char(c)
#undef fscanf
#define fscanf(fpin,format,pdata)	irl_fscanf(fpin,format,pdata)

#define ARGMATCH(arg,option,minmatch) (strncmp(arg,option,MAX(strlen(arg),minmatch)) == 0)
#undef MAX				/* because some systems define this already */
#define MAX(a,b)	(((a) > (b)) ? (a) : (b))
#define OPTCHAR		'-'

extern FILE *fplog;
int load_enabled = 1;			/* reset by --no-load command-line option */
int logfile_enabled = 1;		/* reset by --no-logfile command-line option */
int save_enabled = 1;			/* reset by --no-save command-line option */
int use_readline = 1;			/* reset by --no-readline  command-line option */
static int print_banner = 1;   		/* reset by --no-banner command-line option */
static int read_help_file = 1;		/* reset by --no-help-file command-line option */
static int read_site_file = 1;		/* reset by --no-site-file command-line option */
static int read_translation_file = 1;	/* reset by --no-translation-file command-line option */
static int read_user_file = 1;		/* reset by --no-user-file command-line option */
static int verbose_mode = 1;   		/* reset by --silent command-line option */

static jmp_buf		begin;
static int		gargc;
static char		**gargv;	/* global argument list */
static const char	*infile;	/* input file name */
static int		lineno = 1;
const char		*progname;

FILE			*fin;		/* input file pointer (also used in code.c and string.c) */

static void
author_and_die(void)
{
	static const char *text[] =
	{
		PACKAGE_NAME, " was written by\n\n",

		"\tBrian W. Kernighan and Rob Pike\n\n",

		"and described in their book:\n\n",

		"\tThe UNIX Programming Environment\n",
		"\tPrentice-Hall\n",
		"\t1984\n",
		"\tpp. xii + 357\n",
		"\tISBN 0-13-937699-2 (hardcover), 0-13-937681-X (paperback)\n",
		"\tLCCN QA76.76.O63 K48 1984\n\n",

		"Extensions for IEEE 754 arithmetic, help, additional constants,\n",
		"statements, and functions, initialization files, internationalization,\n",
		"and GNU readline support were added by:\n\n",

		"\t", PACKAGE_BUGREPORT, "\n\n",

		"The extended hoc master Internet source distribution site is at:\n\n",

		"\tftp://ftp.math.utah.edu/pub/hoc\n",
		"\thttp://www.math.utah.edu/pub/hoc/\n\n",

		(const char*)NULL,
	};
	show(text);
	exit(EXIT_SUCCESS);
}

static int
backslash(int c)	/* get next char with \'s interpreted */
{
	static char transtab[] = "a\ab\bf\fn\nr\rt\tv\v"; /* Standard C escapes */

#define is_odigit(x) (isdigit(x) && (x != '8') && (x != '9'))

	if (c != '\\')
		return c;
	c = getc(fin);
	if (islower(c) && (strchr(transtab, c) != (char*)NULL))
		return strchr(transtab, c)[1];
	else if (c == 'E')		/* \E -> ESCape */
	{
		/* NB: Standard C reserves uppercase escapes to
		   implementation-specific extensions */

		return ('\033');	/* ASCII ESCape */
	}
	else if (is_odigit(c))
	{		 /* \o, \oo, \ooo -> octal character number */
		int n;
		int value;

		n = 0;
		value = 0;
		while (is_odigit(c) && ((++n) <= 3))
		{
			value = 8*value + (c - (int)'0');
			c = getc(fin);
		}
		(void)ungetc(c,fin);
		return (value);
	}
	else if (c == (int)'x')
	{	/* \xhhhh... (any number of h's) -> hexadecimal character number */
		int value;

		value = 0;
		c = getc(fin);
		while (isxdigit(c))
		{
			if (isupper(c))
				c = tolower(c);
			if (((int)'a' <= c) && (c <= (int)'f'))
				value = 16*value + (c - (int)'a' + 10);
			else if (isdigit(c))
				value = 16*value + (c - (int)'0');
			c = getc(fin);
		}
		(void)ungetc(c,fin);
		return (value);
	}
	return c;

#undef is_odigit
}

static void
bump_lineno(void)
{
	static fp_t * pdlineno = (fp_t*)NULL;

	if (pdlineno == (fp_t*)NULL)
	{
		Symbol *s;

		s = lookup("__LINENO__");
		if (s == (Symbol*)NULL)
			s = install_const_number("__LINENO__", 0.0);
		make_immutable(s); /* to prevent user code assignments */
		pdlineno = &s->u.val;
	}
	lineno++;
	*pdlineno = (fp_t)lineno;	/* update __LINENO__ value in symbol table */
}

static void
copyright_and_die(void)
{
	static const char *text[] =
	{
		"\n",
		"=================================================================\n",
		"Copyright (C) AT&T 1995\n",
		"All Rights Reserved\n\n",

		"Permission to use, copy, modify, and distribute this software and\n",
		"its documentation for any purpose and without fee is hereby\n",
		"granted, provided that the above copyright notice appear in all\n",
		"copies and that both that the copyright notice and this\n",
		"permission notice and warranty disclaimer appear in supporting\n",
		"documentation, and that the name of AT&T or any of its entities\n",
		"not be used in advertising or publicity pertaining to\n",
		"distribution of the software without specific, written prior\n",
		"permission.\n\n",

		"AT&T DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,\n",
		"INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS.\n",
		"IN NO EVENT SHALL AT&T OR ANY OF ITS ENTITIES BE LIABLE FOR ANY\n",
		"SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES\n",
		"WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER\n",
		"IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,\n",
		"ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF\n",
		"THIS SOFTWARE.\n",
		"=================================================================\n\n",

		(const char*)NULL,
	};
	show(text);
	exit(EXIT_SUCCESS);
}

static void
defnonly(const char *s)	/* warn if illegal definition */
{
	if (!indef)
		execerror(s, "used outside definition");
}

static void
do_init_files(void)
{
	/* Process the optional startup files in documented
	   (in "man hoc") order of use:
		(1) system hoc.rc
		(2) locale hoc.rc
		(3) system help.hoc
		(4) locale help.hoc
		(5) system translations.hoc
		(6) locale translations.hoc
		(7) user .hocrc
	*/

	if (read_site_file)
	{
		do_one_init_file(syshocrc);
		do_one_init_file(get_locale_filename(syshocdir, syshocrcbase));
	}

	if (read_help_file)
	{
		do_one_init_file(syshochlp);
		do_one_init_file(get_locale_filename(syshocdir, syshochlpbase));
	}

	if (read_translation_file)
	{
		do_one_init_file(syshocxlt);
		do_one_init_file(get_locale_filename(syshocdir, syshocxltbase));
	}

#if defined(HAVE_UNIX_HOME_DIRECTORY)
	if (read_user_file)
	{
		const char* userhocrc;
		const char* home;

		home = getenv("HOME");
		if (home == (const char*)NULL)
			return;
		userhocrc = concat3(home, "/", hocrc);
		do_one_init_file(userhocrc);
		efree((void*)userhocrc);
	}
#endif
}

static void
do_one_init_file(const char *filename)
{
	/* If filename is readable, attempt to open it and process it.  Otherwise,
	   return silently. */
	if ((filename != (const char*)NULL) && (access(filename, R_OK) == 0))
	{
		fin = fopen(filename, "r");
		if (fin == (FILE*)NULL)
		{
			(void)fprintf(stderr,
				      msg_translate("%s: can't open %s\n"),
				      progname, filename);
		}
		else
		{
			set_filename(filename);
			run();
			(void)fclose(fin);
			fin = (FILE*)NULL;
		}
	}
}


static void
do_post_args(int *pargc, char* argv[])
{
	int k, m;
	char *p;

	/* Process command-line arguments after initialization files
	   have been read.  Any options that are recognized are
	   removed from argv[], and *pargc is reduced accordingly. */

	for (k = 1; k < *pargc; ++k)
	{
		p = argv[k];
		if (p[0] == OPTCHAR)
		{
			p++;
			if (p[0] == OPTCHAR)
				++p;	/* support GNU/POSIX style --option */

			if (strcmp(p,"") == 0) /* ignore "-" option (meaning, stdin) */
			{
				if (p == (argv[k] + 2))
					p[-1] = '\0'; /* convert "--" to "-" */
				continue;
			}
			else if (ARGMATCH(p,"author",1))
				author_and_die();
			else if (ARGMATCH(p,"copyright",1))
				copyright_and_die();
			else if (ARGMATCH(p,"?",1))
				help_and_die();
			else if (ARGMATCH(p,"help",1))
				help_and_die();
			else if (ARGMATCH(p,"no-banner",4))
			{
				print_banner = 0;
				(void)update_number("__BANNER__", (fp_t)print_banner);
			}
			else if (ARGMATCH(p,"no-help-file",4))
				read_help_file = 0;
			else if (ARGMATCH(p,"no-load",6))
				load_enabled = 0;
			else if (ARGMATCH(p,"no-logfile",6))
				logfile_enabled = 0;
			else if (ARGMATCH(p,"no-readline",4))
			{
				use_readline = 0;
				(void)update_number("__READLINE__", (fp_t)use_readline);
			}
			else if (ARGMATCH(p,"no-save",5))
				save_enabled = 0;
			else if (ARGMATCH(p,"no-site-file",5))
				read_site_file = 0;
			else if (ARGMATCH(p,"no-translation-file",4))
				read_translation_file = 0;
			else if (ARGMATCH(p,"no-user-file",4))
				read_user_file = 0;
			else if (ARGMATCH(p,"quick",1))
			{
				read_help_file = 0;
				read_site_file = 0;
				read_translation_file = 0;
				read_user_file = 0;
			}
			else if (ARGMATCH(p,"silent",1))
			{
				verbose_mode = 0;
				(void)update_number("__VERBOSE__", (fp_t)verbose_mode);
			}
			else if (ARGMATCH(p,"version",1))
				version_and_die();
			else
				usage_and_die(argv[k]);
			/* Remove the option from the argument list */
			for (m = k + 1; m < (*pargc); ++m)
				argv[m-1] = argv[m];
			(*pargc)--;
			k--;	/* avoid missing the next argument */
		}
	}
	argv[*pargc] = (char*)NULL;	/* ANSI C89 Section 2.1.2.2.1: ``argv[argc] shall be a NULL pointer'' */

#if !defined(HAVE_GNU_READLINE)
	use_readline = 0;
	(void)update_number("__READLINE__", (fp_t)use_readline);
#endif

	make_immutable(lookup("__READLINE__"));	/* this decision may someday be changed */
}

static void
do_pre_args(const int *pargc, const char* argv[])
{
	int k;
	const char *p;

	/* Process those command-line arguments that need to be seen
	   before initialization files are read.  No errors are raised
	   here for unrecognized arguments; that will be done in
	   do_post_args().  *pargc and argv[] are left intact. */

	(void)update_number("__BANNER__", (fp_t)print_banner); /* so -no-banner setting is available to user code */
	(void)update_number("__READLINE__", (fp_t)use_readline); /* so -no-readline setting is available to user code */
	(void)update_number("__VERBOSE__",(fp_t)verbose_mode); /* so -silent setting is available to user code */

#if defined(HAVE_IEEE_754)
	(void)install_const_number("__IEEE_754__", 1.0);
#else
	(void)install_const_number("__IEEE_754__", 0.0);
#endif

	(void)install_const_string("__PACKAGE_BUGREPORT__",	PACKAGE_BUGREPORT);
	(void)install_const_string("__PACKAGE_DATE__",		PACKAGE_DATE);
	(void)install_const_string("__PACKAGE_NAME__",		PACKAGE_NAME);
	(void)install_const_string("__PACKAGE_STRING__",	PACKAGE_STRING);
	(void)install_const_string("__PACKAGE_VERSION__",	PACKAGE_VERSION);

	for (k = 1; k < *pargc; ++k)
	{
		p = argv[k];
		if (p[0] == OPTCHAR)
		{
			p++;
			if (p[0] == OPTCHAR)
				++p; /* support GNU/POSIX style --option */

			if (ARGMATCH(p,"no-banner",4))
			{
				print_banner = 0;
				(void)update_number("__BANNER__", (fp_t)print_banner);
			}
			else if (ARGMATCH(p,"no-help-file",4))
				read_help_file = 0;
			else if (ARGMATCH(p,"no-logfile",6))
				logfile_enabled = 0;
			else if (ARGMATCH(p,"no-readline",4))
			{
				use_readline = 0;
				(void)update_number("__READLINE__", (fp_t)use_readline);
			}
			else if (ARGMATCH(p,"no-site-file",5))
				read_site_file = 0;
			else if (ARGMATCH(p,"no-translation-file",4))
				read_translation_file = 0;
			else if (ARGMATCH(p,"no-user-file",4))
				read_user_file = 0;
			else if (ARGMATCH(p,"quick",1))
			{
				read_help_file = 0;
				read_site_file = 0;
				read_translation_file = 0;
				read_user_file = 0;
			}
			else if (ARGMATCH(p,"silent",1))
			{
				verbose_mode = 0;
				(void)update_number("__VERBOSE__", (fp_t)verbose_mode);
			}
		}
	}
}

void
execerror(const char* s, const char* t)	/* recover from run-time error */
{
	warning(s, t);
	(void)fseek(fin, 0L, 2);	/* flush rest of file */
	longjmp(begin, 0);
}

static int
follow(int expect, int ifyes, int ifno)	/* look ahead for >=, etc. */
{
	int ch = getc(fin);

	if (ch == expect)
		return ifyes;
	(void)ungetc(ch, fin);
	return ifno;
}

void
fpecatch(int dummy)	/* catch floating point exceptions */
{
	execerror("floating point exception", (const char*)NULL);
}

static const char *
get_locale_filename(const char *dirname, const char *basename)
{
	/* Given dirname = "/x/y/z" and basename == "foo.bar", return
	   "/x/y/z/LOCALENAME/foo.bar", where LOCALENAME is obtained from
	   get_locale_name() */
	const char *locale;

	locale = get_locale_name();
	if (locale == (const char*)NULL)
		return ((const char*)NULL);
	else
		return (concat5(dirname, "/", locale, "/", basename));
}

static const char *
get_locale_name(void)
{
	/* According to "man 3c setlocale", the language of text
	messages is determined by the locale variable LC_MESSAGES: its
	value is set by the first-defined of three environment
	variables. */

	const char *locale_name;

	locale_name = getenv("LC_ALL");
	if (locale_name == (const char*)NULL)
		locale_name = getenv("LC_MESSAGES");
	if (locale_name == (const char*)NULL)
		locale_name = getenv("LANG");
	return (locale_name);
}

const char*
get_prompt(void)
{
	Symbol *s;

	s = lookup("__PROMPT__");
	if (s == (Symbol*)NULL)
		s = install_string("__PROMPT__", (PACKAGE_NAME "> "));
	return (s->u.str);
}

int
get_verbose(void)
{
	Symbol *s;

	s = lookup("__VERBOSE__");
	if (s == (Symbol*)NULL)
		(void)install_number("__VERBOSE__", (fp_t)verbose_mode);
	else
		verbose_mode = (s->u.val != 0.0);
	return (verbose_mode);
}

static void
help_and_die(void)
{
	static const char *text[] =
	{
		"\n",
		"For additional help, try ", PACKAGE_NAME, "'s help() command, or in a shell,\n",
		"use the UNIX manual page command, man ", PACKAGE_NAME, ".\n",

		(const char*)NULL,
	};

	usage();
	show(text);
	exit(EXIT_SUCCESS);
}

static void
init_lineno(void)
{
	lineno = 0;
	bump_lineno();
}

static void
init_locale(void)
{
#if defined(HAVE_LOCALE_H)
	/* These calls internationalize the hoc language!  However, in
	   order for existing programs to work, numbers MUST use a
	   decimal point, NOT a comma (or other character).  Without
	   this setting, strtod(), fscanf(), and *printf() all alter
	   number formats to locale-specific conventions.  Similarly,
	   settings other than "C" would violate assumptions about
	   sorting in the who() function, and time stamps in the now()
	   function. */

	const char *locale_name;

	locale_name = get_locale_name();
	if (locale_name != (const char*)NULL)
		(void)setlocale(LC_ALL, locale_name);
	(void)setlocale(LC_COLLATE,	"C");
	(void)setlocale(LC_CTYPE,	"C");
	(void)setlocale(LC_MONETARY,	"C");

#if defined(LC_MESSAGES)		/* POSIX.2 extension beyond C89, C++98, and C99 */
	(void)setlocale(LC_MESSAGES,	"C");
#endif

	(void)setlocale(LC_NUMERIC,	"C");
	(void)setlocale(LC_TIME,	"C");
#endif /* defined(HAVE_LOCALE_H) */
}

static void
init_readline(void)
{
#if defined(HAVE_GNU_READLINE)
	(void)rl_bind_key ('\t', rl_insert);	/* TAB is normal, NOT filename completer */
	(void)rl_bind_key ('\033', rl_complete); /* put filename completion on ESCape */
	irl_fd_stdin = dup(fileno(stdin)); /* save handle for original stdin */
#endif
}


void
intcatch(int dummy)	/* catch interrupts */
{
	execerror("interrupt", (const char*)NULL);
}

int
main(int argc, char* argv[])	/* hoc7 */
{
	static int first = 1;

#if YYDEBUG
	yydebug = 3;
#endif
	progname = argv[0];

	init_readline();
	init_locale();
	init_builtins();
	init_lineno();
	do_pre_args(&argc,(const char**)argv);
	do_init_files();
	do_post_args(&argc,argv);
	if (argc == 1) {	/* fake an argument list */
		static char stdhyphen[] = "-";
		static char *stdinonly[] = { stdhyphen, (char*)NULL };

		gargv = stdinonly;
		gargc = 1;
	} else if (first) {	/* for interrupts */
		first = 0;
		gargv = argv+1;
		gargc = argc-1;
	}
	while (moreinput())
		run();
	(void)signal(SIGINT, SIG_IGN);
	return 0;
}

int
moreinput(void)
{
	if (gargc-- <= 0)
		return 0;
	if ((fin != (FILE*)NULL) && (fin != stdin))
	{
		(void)fclose(fin);
		fin = (FILE*)NULL;
	}
	infile = *gargv++;
	if (infile == (const char*)NULL) /* skip over holes from command-line options */
		return moreinput();
	else if (strcmp(infile, "-") == 0) {
		fin = stdin;
		infile = (const char*)NULL;
#if defined(HAVE_GNU_READLINE)
		(void)dup2(irl_fd_stdin,fileno(stdin)); /* restore original stdin */
	} else if ((fin=freopen(infile, "r", stdin)) == (FILE*)NULL) {
#else
	} else if ((fin=fopen(infile, "r")) == (FILE*)NULL) {
#endif
		(void)fprintf(stderr,  msg_translate("%s: can't open %s\n"), progname, infile);
		return moreinput();
	}
	set_filename((infile == (const char*)NULL) ? "/dev/stdin" : infile);
	return 1;
}

void
run(void)	/* execute until EOF */
{
	Symbol *sp;
	(void)setjmp(begin);
	(void)signal(SIGINT, intcatch);
	(void)signal(SIGFPE, fpecatch);

#if defined(SIGXCPU)
	(void)signal(SIGXCPU, xcpucatch);
#endif

	sp = lookup("__CPU_LIMIT__");
	if (sp != (Symbol*)NULL)
		(void)CPULimit(sp->u.val);
	for (initcode(); yyparse(); initcode())
		execute(progbase);
}

void
set_filename(const char *filename)
{
	Symbol *s;
	char temp[sizeof("__FILE__") + sizeof("18446744073709551616" /* 2^64 */) + 2];

	infile_count++;
	(void)sprintf(temp,"__FILE__[%02d]", infile_count);
	(void)install_const_string(temp,filename);

	s = lookup("__FILE__");
	if (s == (Symbol*)NULL)
		(void)install_const_string("__FILE__",filename);
	else
		(void)set_string(s,filename);
	if (current_filename != (const char*)NULL)
		efree((void*)current_filename);
	current_filename = dupstr(filename);
	init_lineno();
}

static void
show(const char *text[])
{
	size_t k;

	for (k = 0; text[k] != (const char*)NULL; ++k)
		(void)fprintf(stderr,"%s", msg_translate(text[k]));
}

static void
usage(void)
{
	static const char *text[] =
	{
		"Usage:\n",
		"\t",
		"",
		"\t[ --author ] [ --? ] [ --copyright] [ --help ] [ --no-banner ]\n",
		"\t\t[ --no-help-file ] [ --no-load ] [ --no-logfile ]\n",
		"\t\t[ --no-readline ] [ --no-save ] [ --no-site-file ]\n",
		"\t\t[ --no-translation-file ] [ --no-user-file ] [ --quick ]\n",
		"\t\t[ --silent ] [ --version ]\n",
		"\t\tinput-file(s) [ -- ] more-input-file(s)\n\n",
		"Options may be prefixed with either one or two hyphens.\n",
		(const char*)NULL,
	};
	text[2] = progname;		/* cannot be done at compile time */
	show(text);
}

static void
usage_and_die(const char *bad_option)
{
	(void)fprintf(stderr, msg_translate("Unrecognized option: [%s]\n"), bad_option);
	usage();
	exit(EXIT_FAILURE);
}

static void
version_and_die(void)
{
	static const char *text[] =
	{
		"This is ", PACKAGE_NAME,
		" version ", PACKAGE_VERSION,
		" of ", PACKAGE_DATE, ".\n\n",
		"Report bugs to ", PACKAGE_BUGREPORT, "\n",
		(const char*)NULL,
	};
	show(text);
	exit(EXIT_SUCCESS);
}

static void
warning(const char *s, const char *t)	/* print warning message */
{
	(void)fflush(stdout);		/* force out any buffered data */
	(void)fflush(stderr);

	s = msg_translate(s);		/* internationalize the output */
	t = msg_translate(t);

#if 1
	/* Use GNU and UNIX standard
		file:lineno:message
	format instead of old style
		program:message [in file] near line nnn */

	(void)fprintf(stderr, "%s:%d:%s", current_filename, lineno, s);
	if (t != (const char*)NULL)
		(void)fprintf(stderr, " %s", t);
	(void)fprintf(stderr, "\n");

	if (logfile_enabled && (fplog != (FILE*)NULL))
	{
		(void)fprintf(fplog, "#-? %s:%d:%s", current_filename, lineno, s);
		if (t != (const char*)NULL)
			(void)fprintf(fplog, " %s", t);
		(void)fprintf(fplog, "\n");
	}
#else
	fprintf(stderr, "%s: %s", progname, s);
	if (t)
		fprintf(stderr, " %s", t);
	if (infile)
		fprintf(stderr, " in %s", infile);
	fprintf(stderr, " near line %d\n", lineno);
#endif

	while (c != '\n' && c != EOF)
		if((c = getc(fin), c) == '\n')	/* flush rest of input line */
			bump_lineno();
		else if (c == EOF && errno == EINTR) {
			clearerr(stdin);	/* ick! */
			errno = 0;
		}
	(void)fflush(stderr);
}

void
yyerror(yyerror_const char* s)	/* report compile-time error */
{
/*rob
	warning(s, (const char *)NULL);
	longjmp(begin, 0);
rob*/
	execerror(s, (const char *)NULL);
}

Symbol *
yygetid(void)		/* get identifier, installing it in the symbol table if necessary */
{
	Symbol *s;
	char sbuf[MAX_NAME+1];
	char *p = sbuf;

	c = getc(fin);
	do {
		if (p >= sbuf + sizeof(sbuf) - 1) {
			*p = '\0';
			execerror("name too long", sbuf);
		}
		*p++ = c;
	} while ((c=getc(fin)) != EOF && IsIdMiddle(c));
	(void)ungetc(c, fin);
	*p = '\0';
	if ((s=lookup(sbuf),s) == (Symbol*)NULL)
		s = install(sbuf, UNDEF, 0.0);

#if defined(DEBUG_YYLEX)
	(void)fprintf(stderr,"yygetid() -> VAR [%s]\n", sbuf);
#endif

	return (s);
}


const char *
yygetstr(void)
{	/* get a quoted string, assuming that the opening quote has just been read */
	char *p;
	static char sbuf[MAX_STRING+1];
	int the_c;

	for (p = sbuf; (the_c=getc(fin)) != '"'; p++) {
		if (the_c == '\n' || the_c == EOF)
			execerror("missing quote", "");
		if (p >= sbuf + sizeof(sbuf) - 1) {
			*p = '\0';
			execerror("string too long", sbuf);
		}
		*p = backslash(the_c);
	}
	*p = '\0';

	return((const char*)&sbuf[0]);
}

int
yylex(void)		/* hoc6 */
{
	while ((c=getc(fin)) == ' ' || c == '\t')
		;
	if (c == EOF)
		return 0;
	if (c == '\\') {
		c = getc(fin);
		if (c == '\n') {
			bump_lineno();
			return yylex();
		}
	}
	if (c == '#') {		/* comment */
		while ((c=getc(fin)) != '\n' && c != EOF)
			;
		if (c == '\n')
			bump_lineno();
		return c;
	}
	if (c == '.' || isdigit(c)) {	/* number */
		fp_t d;
		(void)ungetc(c, fin);
		(void)fscanf(fin, "%lf", &d);
		yylval.sym = install("", NUMBER, d);
#if defined(DEBUG_YYLEX)
		(void)fprintf(stderr,"yylex() -> NUMBER [%lg]\n", d);
#endif
		return NUMBER;
	}
	if (IsIdStart(c)) {
		Symbol *s;
		(void)ungetc(c,fin);
		yylval.sym = s = yygetid();
		return s->type == UNDEF ? VAR : s->type;
	}
	if (c == '$') {	/* argument? */
		int n = 0;
		while (isdigit(c=getc(fin)))
			n = 10 * n + c - '0';
		(void)ungetc(c, fin);
		if (n == 0)
			execerror("strange $...", (const char *)NULL);
		yylval.narg = n;
#if defined(DEBUG_YYLEX)
		(void)fprintf(stderr,"yylex() -> ARG [%d]\n", n);
#endif
		return ARG;
	}
	if (c == '"') {	/* quoted string */
		const char *sbuf;
		sbuf = yygetstr();
#if 0
		/* Old ugly code that masquerades a string on top of a Symbol */
		yylval.sym = (Symbol *)emalloc(strlen(sbuf)+1);
		strcpy((char*)yylval.sym, sbuf);
#else
		/* New code to generate a real Symbol instead */
#if 0
		yylval.sym = (Symbol *)emalloc(sizeof(Symbol));
		yylval.sym->name = (const char*)NULL;
		yylval.sym->type = STRING;
		yylval.sym->u.str = dupstr(sbuf);
		make_immutable(yylval.sym);
		yylval.sym->next = (Symbol*)NULL;
#else
		yylval.sym = install_const_string("", sbuf);
#endif
#endif
#if defined(DEBUG_YYLEX)
		(void)fprintf(stderr,"yylex() -> STRING [%s]\n", sbuf);
#endif
		return STRING;
	}
	switch (c) {
	case ':':	return follow('=', CONSTEQ, ':');
	case '+':	return follow('+', INC, follow('=', ADDEQ, '+'));
	case '-':	return follow('-', DEC, follow('=', SUBEQ, '-'));
	case '*':	return follow('=', MULEQ, '*');
	case '/':	return follow('=', DIVEQ, '/');
	case '%':	return follow('=', MODEQ, '%');
	case '>':	return follow('=', GE, GT);
	case '<':	return follow('=', LE, LT);
	case '=':	return follow('=', EQ, '=');
	case '!':	return follow('=', NE, NOT);
	case '|':	return follow('|', OR, '|');
	case '&':	return follow('&', AND, '&');
	case '\n':	bump_lineno(); return '\n';
	default:	return c;
	}
}
static YYCONST yytabelem yyexca[] ={
-1, 1,
	0, -1,
	-2, 0,
	};
# define YYNPROD 133
# define YYLAST 1968
static YYCONST yytabelem yyact[]={

    83,   215,     7,    91,   142,   143,   144,   145,   146,   147,
   174,   170,   214,   293,   204,   141,   140,   242,   113,    87,
   117,   117,   117,   284,   216,    88,    89,    66,   214,    67,
   285,    10,    64,   248,   295,     6,   203,    65,   136,   137,
   138,   139,   274,    66,   269,   270,   268,   270,    64,    62,
   267,    63,   253,    65,   252,   251,   107,   249,   247,   235,
   218,   177,   241,   156,   157,   158,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   240,   213,   172,
    11,     2,   202,   173,    67,    56,    57,    58,    59,    60,
    81,    85,   178,   180,   182,   183,   184,   185,   186,   155,
    67,   187,   189,   191,   192,   193,   194,   195,   196,   197,
   198,   199,   200,   201,   154,   153,   152,   151,   150,   149,
   148,   134,   205,   205,   205,   211,   133,   132,   131,   217,
   130,   219,   220,   172,   172,   172,    66,   206,   207,   115,
   129,    64,    62,   128,    63,   127,    65,   126,   123,   232,
   233,   234,   122,   172,   172,   172,   172,   121,   176,    86,
   210,    77,   116,     5,    84,   100,     4,   125,     3,     1,
    24,   172,   172,    90,    23,   172,   172,    22,   124,     0,
   114,     0,    43,   119,   120,     0,     0,     0,    61,    82,
     0,     0,     0,    67,     0,     0,     0,     0,     0,     0,
    43,    43,    43,   243,   245,    66,   209,     0,     0,   297,
    64,    62,     0,    63,   243,    65,     0,     0,    43,    66,
     0,     0,     0,     0,    64,    62,   291,    63,     0,    65,
     0,   250,     0,     0,    93,    94,    95,    96,    97,    92,
     0,     0,     0,     0,    10,     0,   175,   171,   211,   205,
   211,    98,    99,     0,     0,     0,     0,   275,   172,    43,
     0,     0,    67,   272,     0,   172,   278,   279,   211,   211,
     0,   282,    43,    43,    37,     0,    67,    39,     0,    38,
     0,    43,    43,   271,     0,   273,   205,   108,   109,   110,
   111,   112,   294,    11,   211,     0,   211,   286,    61,    82,
   292,     0,     0,   280,   281,    43,    68,    69,    70,    71,
    72,    73,     0,    43,    43,    43,    82,    61,    78,     0,
   299,     0,   300,   226,   227,   228,   229,   230,   231,   296,
     0,   298,     0,    43,    43,    43,    43,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    10,     0,     0,     0,
     0,    43,    43,    61,     0,    43,    43,    25,     0,    61,
    82,    61,    82,     0,     0,     0,     0,     0,    61,    82,
    61,    82,    66,     0,     0,     0,    37,    64,    62,    39,
    63,    38,    65,    43,    43,     0,     0,     0,     0,     0,
     0,     0,    61,    82,    43,    11,   102,   103,   104,   105,
   106,   101,    82,    82,    82,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    82,    82,    82,
    82,     0,     0,     0,    61,    82,    61,    82,    43,    67,
    43,     0,     0,     0,     0,     0,     0,     0,    43,     0,
     0,     0,     0,     0,     0,    43,     0,    37,    43,    43,
    39,    43,    38,     0,     0,     0,     0,    82,    82,    25,
     0,   208,     0,    61,    82,     0,    75,    74,    68,    69,
    70,    71,    72,    73,    43,     0,    43,     0,     0,     0,
    75,    74,    68,    69,    70,    71,    72,    73,     0,     0,
     9,    26,    47,    19,    14,     0,    44,    45,    46,    10,
    27,    18,    17,    12,    13,    28,    29,    31,    32,    33,
    30,    48,    49,    34,    35,    50,    20,    21,    51,    52,
    53,    15,    54,    36,    55,    16,     0,     0,     0,    37,
    25,     0,    39,     0,    38,     0,    47,     0,    80,     0,
     0,     0,    40,    41,    42,     0,     0,     0,    11,    79,
     0,     0,     0,     0,     0,    48,    49,     0,     0,    50,
     0,     0,    51,    52,    53,    76,    54,     0,    55,    37,
   289,     0,    39,     0,    38,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    26,    47,    19,    14,     0,    44,    45,
    46,     0,    27,    18,    17,     0,     0,    28,    29,    31,
    32,    33,    30,    48,    49,    34,    35,    50,    20,    21,
    51,    52,    53,    15,    54,    36,    55,    16,    37,   288,
     0,    39,     0,    38,    74,    68,    69,    70,    71,    72,
    73,     0,     0,    66,    40,    41,    42,   290,    64,    62,
     0,    63,     0,    65,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,    26,    47,    19,    14,     0,    44,
    45,    46,     0,    27,    18,    17,     0,     0,    28,    29,
    31,    32,    33,    30,    48,    49,    34,    35,    50,    20,
    21,    51,    52,    53,    15,    54,    36,    55,    16,    37,
    67,     0,    39,   266,    38,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    40,    41,    42,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    37,
     0,     0,    39,   265,    38,     0,    26,    47,     0,    14,
     0,     0,     0,     0,     0,    27,     0,     0,     0,     0,
    28,    29,    31,    32,    33,    30,    48,    49,    34,    35,
    50,     0,     0,    51,    52,    53,    15,    54,    36,    55,
    16,     0,     0,     0,     0,     0,    26,    47,     0,    14,
     0,     0,     0,     0,     0,    27,     0,    40,    41,    42,
    28,    29,    31,    32,    33,    30,    48,    49,    34,    35,
    50,     0,     0,    51,    52,    53,    15,    54,    36,    55,
    16,    37,     0,     0,    39,   264,    38,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    40,    41,    42,
     0,     0,     0,     0,     0,    26,    47,     0,    14,     0,
     0,     0,     0,     0,    27,     0,     0,     0,     0,    28,
    29,    31,    32,    33,    30,    48,    49,    34,    35,    50,
     0,     0,    51,    52,    53,    15,    54,    36,    55,    16,
    37,   263,     0,    39,     0,    38,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    40,    41,    42,     0,
     0,     0,     0,     0,    75,    74,    68,    69,    70,    71,
    72,    73,     0,     0,     0,     0,    26,    47,     0,    14,
     0,    37,   259,     0,    39,    27,    38,     0,     0,     0,
    28,    29,    31,    32,    33,    30,    48,    49,    34,    35,
    50,     0,     0,    51,    52,    53,    15,    54,    36,    55,
    16,     0,     0,     0,     0,     0,    26,    47,     0,    14,
     0,    37,   258,     0,    39,    27,    38,    40,    41,    42,
    28,    29,    31,    32,    33,    30,    48,    49,    34,    35,
    50,     0,     0,    51,    52,    53,    15,    54,    36,    55,
    16,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    37,     0,     0,    39,   257,    38,    40,    41,    42,
     0,     0,     0,     0,     0,     0,     0,     0,    66,     0,
     0,     0,   287,    64,    62,     0,    63,     0,    65,     0,
     0,     0,     0,     0,     0,     0,     0,     0,    26,    47,
     0,    14,     0,     0,     0,     0,     0,    27,     0,     0,
     0,     0,    28,    29,    31,    32,    33,    30,    48,    49,
    34,    35,    50,     0,     0,    51,    52,    53,    15,    54,
    36,    55,    16,    37,   224,    67,    39,     0,    38,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    40,
    41,    42,     0,     0,     0,     0,     0,    26,    47,     0,
    14,     0,     0,     0,     0,     0,    27,     0,     0,     0,
     0,    28,    29,    31,    32,    33,    30,    48,    49,    34,
    35,    50,     0,     0,    51,    52,    53,    15,    54,    36,
    55,    16,    37,     0,     0,    39,     0,    38,    26,    47,
     0,    14,     0,     0,     0,     0,     0,    27,    40,    41,
    42,     0,    28,    29,    31,    32,    33,    30,    48,    49,
    34,    35,    50,     0,     0,    51,    52,    53,    15,    54,
    36,    55,    16,     0,     0,     0,     0,     0,    26,    47,
     0,    14,     0,     0,     0,     0,     0,    27,     0,    40,
    41,    42,    28,    29,    31,    32,    33,    30,    48,    49,
    34,    35,    50,     0,     0,    51,    52,    53,    15,    54,
    36,    55,    16,     0,     0,     0,     0,     0,    26,    47,
     0,    14,     0,     0,     0,     0,     0,    27,     0,    40,
    41,    42,    28,    29,    31,    32,    33,    30,    48,    49,
    34,    35,    50,     0,     0,    51,    52,    53,    15,    54,
    36,    55,    16,     0,     0,     0,     0,     0,    66,     0,
     0,    78,   225,    64,    62,     0,    63,     0,    65,    40,
    41,    42,     0,     0,     0,     0,     0,     0,     0,    75,
    74,    68,    69,    70,    71,    72,    73,     0,     0,     0,
    26,    47,     0,    14,     0,     0,     0,     0,     0,    27,
     0,     0,    10,     0,    28,    29,    31,    32,    33,    30,
    48,    49,    34,    35,    50,    67,     0,    51,    52,    53,
    15,    54,    36,    55,    16,     0,     0,     0,     0,    66,
     0,     0,    78,     0,    64,    62,     0,    63,     0,    65,
     0,    40,    41,    42,     0,     0,     0,     0,     0,    26,
    47,    11,    14,     0,     0,     0,     0,     0,    27,     0,
     0,     0,     0,    28,    29,    31,    32,    33,    30,    48,
    49,    34,    35,    50,     0,     0,    51,    52,    53,    15,
    54,    36,    55,    16,    66,     0,    67,    78,     0,    64,
    62,     0,    63,     0,    65,     0,     0,     0,     0,    66,
    40,    41,    42,   262,    64,    62,     0,    63,    66,    65,
     0,     0,   261,    64,    62,     0,    63,    66,    65,     0,
     0,   260,    64,    62,     0,    63,    66,    65,     0,     0,
     0,    64,    62,   256,    63,     0,    65,     0,    66,     0,
     0,    67,   255,    64,    62,     0,    63,    66,    65,     0,
     0,   254,    64,    62,     0,    63,    67,    65,    66,     0,
     0,     0,     0,    64,    62,    67,    63,     0,    65,     0,
     0,     0,     0,     0,    67,     0,     0,     0,     0,    47,
     0,    80,     0,    67,     0,     0,     0,     0,     0,     0,
     0,     0,    79,     0,     0,    67,     0,     0,    48,    49,
     0,     0,    50,     0,    67,    51,    52,    53,    76,    54,
     0,    55,     0,     0,     0,    67,     0,     0,     0,    75,
    74,    68,    69,    70,    71,    72,    73,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    47,     0,    80,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    79,     0,     0,     0,     0,     0,    48,
    49,     0,     0,    50,     0,     0,    51,    52,    53,    76,
    54,     0,    55,     0,     0,     0,     0,     0,     0,     0,
    75,    74,    68,    69,    70,    71,    72,    73,     0,     0,
     0,     0,     0,     0,     0,    47,     0,    80,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,    79,     0,
     0,     0,     0,     0,    48,    49,     0,     0,    50,     0,
     0,    51,    52,    53,    76,    54,     0,    55,     0,     0,
     0,     0,     0,     0,     0,    75,    74,    68,    69,    70,
    71,    72,    73,     0,     0,     0,     0,     0,     0,     0,
    75,    74,    68,    69,    70,    71,    72,    73,     0,    75,
    74,    68,    69,    70,    71,    72,    73,     0,    75,    74,
    68,    69,    70,    71,    72,    73,     0,    75,    74,    68,
    69,    70,    71,    72,    73,     0,   212,     0,     8,    75,
    74,    68,    69,    70,    71,    72,    73,     0,    75,    74,
    68,    69,    70,    71,    72,    73,   118,   118,   118,    75,
    74,    68,    69,    70,    71,    72,    73,     0,     0,     0,
     0,     0,     0,     0,   135,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,   135,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,   179,   181,
     0,     0,     0,     0,     0,     0,     0,   188,   190,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   221,
   222,   223,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   236,
   237,   238,   239,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,   188,   190,     0,
     0,   179,   181,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   244,
   246,     0,     0,     0,     0,     0,     0,     0,     0,     0,
   244,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   276,     0,     0,     0,     0,     0,
     0,   277,     0,     0,     0,     0,     0,   283 };
static YYCONST yytabelem yypact[]={

-10000000,   234,-10000000,    21,    21,    21,    21,  1292,   489,    21,
-10000000,-10000000,  -241,  -241,   -58,   104,    -5,  1092,-10000000,  1092,
  1092,  1092,   117,   112,   108,-10000000,-10000000,-10000000,   107,   105,
   103,   100,    90,    88,    87,    86,    81,  1092,  1092,  1092,
  1092,  -244,  -245,  -296,-10000000,-10000000,-10000000,-10000000,    80,    79,
    78,    77,    76,    75,    74,    59,-10000000,-10000000,-10000000,-10000000,
-10000000,-10000000,  1092,  1092,  1092,  1092,  1092,  1092,  1092,  1092,
  1092,  1092,  1092,  1092,  1092,  1092,   -50,-10000000,  1092,    43,
   -51,-10000000,  -296,  1421,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,
-10000000,  1092,  1092,  1092,  1092,  1092,  1092,  1092,-10000000,-10000000,
  1092,  1092,  1092,  1092,  1092,  1092,  1092,  1092,  1092,  1092,
  1092,  1092,  1092,  1421,  -296,    42,    -8,  1347,  1092,    -8,
    -8,  1092,  1092,  1092,   336,    38,  -259,  -234,  1092,    19,
  1092,  1092,  1092,  1092,  1092,  1033,  1221,   -65,   -65,   -65,
-10000000,-10000000,   278,   278,   278,   278,   278,   278,  1092,  1092,
  1092,    18,  1092,  1092,  1092,  1092,   -10,   -10,   -65,   -65,
   -65,   -65,    99,    99,    99,    99,    99,    99,     6,   335,
  1092,  1092,  1347,  -275,  1092,  1092,    37,    22,  1347,  1092,
  1347,  1092,  1421,  1421,  1421,  1421,  1421,  1347,  1092,  1347,
  1092,  1421,  1421,  1421,  1421,  1421,  1421,  1421,  1421,  1421,
  1421,  1421,  1092,  1092,    17,  1421,   -26,    16,-10000000,-10000000,
-10000000,  1347,  1092,  1092,    14,    13,    11,  1410,-10000000,  1401,
  1389,   961,   921,   881,-10000000,-10000000,-10000000,-10000000,-10000000,-10000000,
-10000000,-10000000,  1380,  1371,  1362,-10000000,   840,   781,   699,   659,
     9,     5,     3,  1347,  1092,  1347,  1092,   407,  1092,   407,
     1,-10000000,-10000000,-10000000,-10000000,-10000000,  1092,  1092,-10000000,-10000000,
-10000000,-10000000,-10000000,-10000000,  1092,  1092,  1092,   407,   407,-10000000,
  1092,-10000000,   -29,-10000000,-10000000,   981,   588,   529,   606,   182,
-10000000,-10000000,  1347,  1092,-10000000,  1092,  -252,-10000000,-10000000,-10000000,
-10000000,  1092,    -7,   407,   168,   407,-10000000,-10000000,-10000000,-10000000,
-10000000 };
static YYCONST yytabelem yypgo[]={

     0,     0,    35,   164,   162,   178,    14,   177,   174,   170,
   139,    23,   161,  1696,   180,   159,    17,   169,    81,   168,
   158,    61 };
static YYCONST yytabelem yyr1[]={

     0,    17,    17,    17,    17,    17,    17,    17,    17,    17,
    18,    18,     3,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
     3,     3,    12,    12,    12,    12,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     6,
     7,     8,     9,    10,    11,     5,     5,     5,    14,    14,
    14,    14,    14,    14,    14,    14,    14,    14,    14,    14,
    14,    13,    13,    13,    13,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     4,     4,     4,
     4,    20,    19,    21,    19,    15,    15,    15,    16,    16,
    16,    16,    16 };
static YYCONST yytabelem yyr2[]={

     0,     0,     4,     6,     7,     7,     7,     7,     7,     7,
     2,     2,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     7,     7,     7,     7,
     7,     7,     7,     7,     7,     7,     3,     3,     3,     5,
    11,     5,     5,     5,    13,    21,    13,    19,     7,     3,
     3,     3,     3,     1,     1,     1,     4,     4,     3,     3,
     2,     7,     9,     9,     9,     9,     7,     9,    13,    13,
    17,     2,     5,     5,     5,     3,     3,     3,     2,    11,
     9,     9,     9,     7,     9,    13,    13,     9,     9,     7,
     7,     7,     7,     7,     7,     7,     5,     5,     7,     7,
     7,     7,     7,     7,     7,     7,     5,     5,     5,     5,
     5,     7,     7,     7,     7,     7,     7,     3,     3,     7,
     7,     1,    13,     1,    13,     2,     2,     2,     1,     3,
     3,     7,     7 };
static YYCONST yytabelem yychk[]={

-10000000,   -17,   -18,   -19,    -3,   -12,    -2,    -1,   -13,   256,
    10,    59,   269,   270,   260,   287,   291,   268,   267,   259,
   282,   283,    -7,    -8,    -9,   123,   257,   266,   271,   272,
   276,   273,   274,   275,   279,   280,   289,    40,    45,    43,
   308,   309,   310,   -14,   262,   263,   264,   258,   277,   278,
   281,   284,   285,   286,   288,   290,   -18,   -18,   -18,   -18,
   -18,   -14,    43,    45,    42,    47,    37,    94,   300,   301,
   302,   303,   304,   305,   299,   298,   287,   -12,    40,   271,
   260,   -18,   -14,    -1,    -3,   -18,   -15,   260,   266,   267,
   -15,    61,   297,   292,   293,   294,   295,   296,   309,   310,
    61,   297,   292,   293,   294,   295,   296,    61,   292,   293,
   294,   295,   296,    -1,   -14,   -10,    -4,    -1,   -13,    -4,
    -4,    40,    40,    40,    -5,   -10,    40,    40,    40,    40,
    40,    40,    40,    40,    40,   -13,    -1,    -1,    -1,    -1,
   260,   260,   300,   301,   302,   303,   304,   305,    40,    40,
    40,    40,    40,    40,    40,    40,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    61,   297,    -1,    40,    61,   297,   -20,   -21,    -1,   -13,
    -1,   -13,    -1,    -1,    -1,    -1,    -1,    -1,   -13,    -1,
   -13,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    40,    44,    -6,    -1,    -6,    -6,   125,   -18,
    -2,    -1,   -13,    40,   287,   260,   258,    -1,    41,    -1,
    -1,   -13,   -13,   -13,    41,    41,   -14,   -14,   -14,   -14,
   -14,   -14,    -1,    -1,    -1,    41,   -13,   -13,   -13,   -13,
    40,    40,   -16,    -1,   -13,    -1,   -13,    41,    59,    41,
   -16,    41,    41,    41,    41,    41,    44,    44,    41,    41,
    41,    41,    41,    41,    44,    44,    44,    41,    41,    41,
    44,    -2,    -6,    -2,    41,    -1,   -13,   -13,    -1,    -1,
    -2,    -2,    -1,   -13,   -11,    59,   -11,    41,    41,    41,
    41,    44,    -6,   265,    -1,    41,    -2,    41,    -2,   -11,
   -11 };
static YYCONST yytabelem yydef[]={

     1,    -2,     2,     0,    78,    60,     0,     0,     0,     0,
    10,    11,     0,     0,    76,    59,    77,    38,    53,     0,
     0,     0,     0,     0,     0,    55,    75,    53,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    71,    50,    51,    52,    58,     0,     0,
     0,     0,     0,     0,     0,     0,     3,     4,     5,     6,
     7,    74,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    59,    60,     0,     0,
     0,     8,    72,    73,    78,     9,   121,   125,   126,   127,
   123,     0,     0,     0,     0,     0,     0,     0,   109,   110,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    39,     0,     0,    41,   117,   118,    42,
    43,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    96,    97,   106,
   107,   108,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,    90,    91,    92,    93,
    94,    95,    98,    99,   100,   101,   102,   103,   104,   105,
     0,     0,     0,     0,     0,     0,     0,     0,    12,    34,
    13,    35,    14,    15,    16,    17,    18,    19,    32,    20,
    33,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,    31,   128,     0,     0,    49,     0,     0,    48,    56,
    57,    36,    37,   128,     0,     0,     0,     0,    83,     0,
     0,     0,     0,     0,    61,    89,   111,   112,   113,   114,
   115,   116,     0,     0,     0,    66,     0,     0,     0,     0,
     0,     0,     0,   129,   130,   119,   120,     0,     0,     0,
     0,    65,    80,    81,    82,    84,     0,     0,    87,    88,
    62,    63,    64,    67,     0,     0,     0,     0,     0,    40,
     0,    54,     0,    54,    79,     0,     0,     0,     0,     0,
   122,   124,   131,   132,    44,     0,    46,    85,    86,    68,
    69,     0,     0,     0,     0,     0,    54,    70,    54,    47,
    45 };
typedef struct
#ifdef __cplusplus
	yytoktype
#endif
{ char *t_name; int t_val; } yytoktype;
#ifndef YYDEBUG
#	define YYDEBUG	0	/* don't allow debugging */
#endif

#if YYDEBUG

yytoktype yytoks[] =
{
	"NUMBER",	257,
	"STRING",	258,
	"PRINT",	259,
	"VAR",	260,
	"UNDEF",	261,
	"WHILE",	262,
	"FOR",	263,
	"IF",	264,
	"ELSE",	265,
	"FUNCTION",	266,
	"PROCEDURE",	267,
	"RETURN",	268,
	"FUNC",	269,
	"PROC",	270,
	"READ",	271,
	"ABORT",	272,
	"BLTIN0",	273,
	"BLTIN1",	274,
	"BLTIN2",	275,
	"HEX",	276,
	"HEXFP",	277,
	"HEXINT",	278,
	"INDEX",	279,
	"LENGTH",	280,
	"NUMTOSTR",	281,
	"PRINTF",	282,
	"PRINTLN",	283,
	"STRBLTIN0",	284,
	"STRBLTIN1",	285,
	"STRBLTIN2",	286,
	"STRVAR",	287,
	"STRFTIME",	288,
	"STRTONUM",	289,
	"SUBSTR",	290,
	"ARG",	291,
	"=",	61,
	"ADDEQ",	292,
	"SUBEQ",	293,
	"MULEQ",	294,
	"DIVEQ",	295,
	"MODEQ",	296,
	"CONSTEQ",	297,
	"OR",	298,
	"AND",	299,
	"GT",	300,
	"GE",	301,
	"LT",	302,
	"LE",	303,
	"EQ",	304,
	"NE",	305,
	"+",	43,
	"-",	45,
	"*",	42,
	"/",	47,
	"%",	37,
	"UNARYMINUS",	306,
	"UNARYPLUS",	307,
	"NOT",	308,
	"INC",	309,
	"DEC",	310,
	"^",	94,
	"-unknown-",	-1	/* ends search */
};

char * yyreds[] =
{
	"-no such reduction-",
	"list : /* empty */",
	"list : list eos",
	"list : list defn eos",
	"list : list asgn eos",
	"list : list strasgn eos",
	"list : list stmt eos",
	"list : list expr eos",
	"list : list strexpr eos",
	"list : list error eos",
	"eos : '\n'",
	"eos : ';'",
	"asgn : VAR '=' expr",
	"asgn : VAR CONSTEQ expr",
	"asgn : VAR ADDEQ expr",
	"asgn : VAR SUBEQ expr",
	"asgn : VAR MULEQ expr",
	"asgn : VAR DIVEQ expr",
	"asgn : VAR MODEQ expr",
	"asgn : STRVAR '=' expr",
	"asgn : STRVAR CONSTEQ expr",
	"asgn : STRVAR ADDEQ expr",
	"asgn : STRVAR SUBEQ expr",
	"asgn : STRVAR MULEQ expr",
	"asgn : STRVAR DIVEQ expr",
	"asgn : STRVAR MODEQ expr",
	"asgn : ARG '=' expr",
	"asgn : ARG ADDEQ expr",
	"asgn : ARG SUBEQ expr",
	"asgn : ARG MULEQ expr",
	"asgn : ARG DIVEQ expr",
	"asgn : ARG MODEQ expr",
	"strasgn : STRVAR '=' strexpr",
	"strasgn : STRVAR CONSTEQ strexpr",
	"strasgn : VAR '=' strexpr",
	"strasgn : VAR CONSTEQ strexpr",
	"stmt : expr",
	"stmt : strexpr",
	"stmt : RETURN",
	"stmt : RETURN expr",
	"stmt : PROCEDURE begin '(' arglist ')'",
	"stmt : PRINT prlist",
	"stmt : PRINTF prlist",
	"stmt : PRINTLN prlist",
	"stmt : while '(' cond ')' stmt end",
	"stmt : for '(' cond ';' cond ';' cond ')' stmt end",
	"stmt : if '(' cond ')' stmt end",
	"stmt : if '(' cond ')' stmt end ELSE stmt end",
	"stmt : '{' stmtlist '}'",
	"cond : expr",
	"while : WHILE",
	"for : FOR",
	"if : IF",
	"begin : /* empty */",
	"end : /* empty */",
	"stmtlist : /* empty */",
	"stmtlist : stmtlist eos",
	"stmtlist : stmtlist stmt",
	"string : STRING",
	"string : STRVAR",
	"string : strasgn",
	"string : '(' strexpr ')'",
	"string : HEXFP '(' expr ')'",
	"string : HEXINT '(' expr ')'",
	"string : NUMTOSTR '(' expr ')'",
	"string : READ '(' STRVAR ')'",
	"string : STRBLTIN0 '(' ')'",
	"string : STRBLTIN1 '(' strexpr ')'",
	"string : STRBLTIN2 '(' strexpr ',' strexpr ')'",
	"string : STRFTIME '(' strexpr ',' expr ')'",
	"string : SUBSTR '(' strexpr ',' expr ',' expr ')'",
	"strexpr : string",
	"strexpr : strexpr string",
	"strexpr : strexpr expr",
	"strexpr : expr string",
	"expr : NUMBER",
	"expr : VAR",
	"expr : ARG",
	"expr : asgn",
	"expr : FUNCTION begin '(' arglist ')'",
	"expr : READ '(' VAR ')'",
	"expr : ABORT '(' STRING ')'",
	"expr : HEX '(' expr ')'",
	"expr : BLTIN0 '(' ')'",
	"expr : BLTIN1 '(' expr ')'",
	"expr : BLTIN2 '(' expr ',' expr ')'",
	"expr : INDEX '(' strexpr ',' strexpr ')'",
	"expr : LENGTH '(' strexpr ')'",
	"expr : STRTONUM '(' strexpr ')'",
	"expr : '(' expr ')'",
	"expr : expr '+' expr",
	"expr : expr '-' expr",
	"expr : expr '*' expr",
	"expr : expr '/' expr",
	"expr : expr '%' expr",
	"expr : expr '^' expr",
	"expr : '-' expr",
	"expr : '+' expr",
	"expr : expr GT expr",
	"expr : expr GE expr",
	"expr : expr LT expr",
	"expr : expr LE expr",
	"expr : expr EQ expr",
	"expr : expr NE expr",
	"expr : expr AND expr",
	"expr : expr OR expr",
	"expr : NOT expr",
	"expr : INC VAR",
	"expr : DEC VAR",
	"expr : VAR INC",
	"expr : VAR DEC",
	"expr : string GT string",
	"expr : string GE string",
	"expr : string LT string",
	"expr : string LE string",
	"expr : string EQ string",
	"expr : string NE string",
	"prlist : expr",
	"prlist : strexpr",
	"prlist : prlist ',' expr",
	"prlist : prlist ',' strexpr",
	"defn : FUNC procname",
	"defn : FUNC procname '(' ')' stmt",
	"defn : PROC procname",
	"defn : PROC procname '(' ')' stmt",
	"procname : VAR",
	"procname : FUNCTION",
	"procname : PROCEDURE",
	"arglist : /* empty */",
	"arglist : expr",
	"arglist : strexpr",
	"arglist : arglist ',' expr",
	"arglist : arglist ',' strexpr",
};
#endif /* YYDEBUG */
# line	1 "/usr/ccs/bin/yaccpar"
/*
 * Copyright (c) 1993 by Sun Microsystems, Inc.
 */

#pragma ident	"@(#)yaccpar	6.16	99/01/20 SMI"

/*
** Skeleton parser driver for yacc output
*/

/*
** yacc user known macros and defines
*/
#define YYERROR		goto yyerrlab
#define YYACCEPT	return(0)
#define YYABORT		return(1)
#define YYBACKUP( newtoken, newvalue )\
{\
	if ( yychar >= 0 || ( yyr2[ yytmp ] >> 1 ) != 1 )\
	{\
		yyerror( "syntax error - cannot backup" );\
		goto yyerrlab;\
	}\
	yychar = newtoken;\
	yystate = *yyps;\
	yylval = newvalue;\
	goto yynewstate;\
}
#define YYRECOVERING()	(!!yyerrflag)
#define YYNEW(type)	malloc(sizeof(type) * yynewmax)
#define YYCOPY(to, from, type) \
	(type *) memcpy(to, (char *) from, yymaxdepth * sizeof (type))
#define YYENLARGE( from, type) \
	(type *) realloc((char *) from, yynewmax * sizeof(type))
#ifndef YYDEBUG
#	define YYDEBUG	1	/* make debugging available */
#endif

/*
** user known globals
*/
int yydebug;			/* set to 1 to get debugging */

/*
** driver internal defines
*/
#define YYFLAG		(-10000000)

/*
** global variables used by the parser
*/
YYSTYPE *yypv;			/* top of value stack */
int *yyps;			/* top of state stack */

int yystate;			/* current state */
int yytmp;			/* extra var (lasts between blocks) */

int yynerrs;			/* number of errors */
int yyerrflag;			/* error recovery flag */
int yychar;			/* current input token number */



#ifdef YYNMBCHARS
#define YYLEX()		yycvtok(yylex())
/*
** yycvtok - return a token if i is a wchar_t value that exceeds 255.
**	If i<255, i itself is the token.  If i>255 but the neither 
**	of the 30th or 31st bit is on, i is already a token.
*/
#if defined(__STDC__) || defined(__cplusplus)
int yycvtok(int i)
#else
int yycvtok(i) int i;
#endif
{
	int first = 0;
	int last = YYNMBCHARS - 1;
	int mid;
	wchar_t j;

	if(i&0x60000000){/*Must convert to a token. */
		if( yymbchars[last].character < i ){
			return i;/*Giving up*/
		}
		while ((last>=first)&&(first>=0)) {/*Binary search loop*/
			mid = (first+last)/2;
			j = yymbchars[mid].character;
			if( j==i ){/*Found*/ 
				return yymbchars[mid].tvalue;
			}else if( j<i ){
				first = mid + 1;
			}else{
				last = mid -1;
			}
		}
		/*No entry in the table.*/
		return i;/* Giving up.*/
	}else{/* i is already a token. */
		return i;
	}
}
#else/*!YYNMBCHARS*/
#define YYLEX()		yylex()
#endif/*!YYNMBCHARS*/

/*
** yyparse - return 0 if worked, 1 if syntax error not recovered from
*/
#if defined(__STDC__) || defined(__cplusplus)
int yyparse(void)
#else
int yyparse()
#endif
{
	register YYSTYPE *yypvt = 0;	/* top of value stack for $vars */

#if defined(__cplusplus) || defined(lint)
/*
	hacks to please C++ and lint - goto's inside
	switch should never be executed
*/
	static int __yaccpar_lint_hack__ = 0;
	switch (__yaccpar_lint_hack__)
	{
		case 1: goto yyerrlab;
		case 2: goto yynewstate;
	}
#endif

	/*
	** Initialize externals - yyparse may be called more than once
	*/
	yypv = &yyv[-1];
	yyps = &yys[-1];
	yystate = 0;
	yytmp = 0;
	yynerrs = 0;
	yyerrflag = 0;
	yychar = -1;

#if YYMAXDEPTH <= 0
	if (yymaxdepth <= 0)
	{
		if ((yymaxdepth = YYEXPAND(0)) <= 0)
		{
			yyerror("yacc initialization error");
			YYABORT;
		}
	}
#endif

	{
		register YYSTYPE *yy_pv;	/* top of value stack */
		register int *yy_ps;		/* top of state stack */
		register int yy_state;		/* current state */
		register int  yy_n;		/* internal state number info */
	goto yystack;	/* moved from 6 lines above to here to please C++ */

		/*
		** get globals into registers.
		** branch to here only if YYBACKUP was called.
		*/
	yynewstate:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;
		goto yy_newstate;

		/*
		** get globals into registers.
		** either we just started, or we just finished a reduction
		*/
	yystack:
		yy_pv = yypv;
		yy_ps = yyps;
		yy_state = yystate;

		/*
		** top of for (;;) loop while no reductions done
		*/
	yy_stack:
		/*
		** put a state and value onto the stacks
		*/
#if YYDEBUG
		/*
		** if debugging, look up token value in list of value vs.
		** name pairs.  0 and negative (-1) are special values.
		** Note: linear search is used since time is not a real
		** consideration while debugging.
		*/
		if ( yydebug )
		{
			register int yy_i;

			printf( "State %d, token ", yy_state );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ++yy_ps >= &yys[ yymaxdepth ] )	/* room on stack? */
		{
			/*
			** reallocate and recover.  Note that pointers
			** have to be reset, or bad things will happen
			*/
			long yyps_index = (yy_ps - yys);
			long yypv_index = (yy_pv - yyv);
			long yypvt_index = (yypvt - yyv);
			int yynewmax;
#ifdef YYEXPAND
			yynewmax = YYEXPAND(yymaxdepth);
#else
			yynewmax = 2 * yymaxdepth;	/* double table size */
			if (yymaxdepth == YYMAXDEPTH)	/* first time growth */
			{
				char *newyys = (char *)YYNEW(int);
				char *newyyv = (char *)YYNEW(YYSTYPE);
				if (newyys != 0 && newyyv != 0)
				{
					yys = YYCOPY(newyys, yys, int);
					yyv = YYCOPY(newyyv, yyv, YYSTYPE);
				}
				else
					yynewmax = 0;	/* failed */
			}
			else				/* not first time */
			{
				yys = YYENLARGE(yys, int);
				yyv = YYENLARGE(yyv, YYSTYPE);
				if (yys == 0 || yyv == 0)
					yynewmax = 0;	/* failed */
			}
#endif
			if (yynewmax <= yymaxdepth)	/* tables not expanded */
			{
				yyerror( "yacc stack overflow" );
				YYABORT;
			}
			yymaxdepth = yynewmax;

			yy_ps = yys + yyps_index;
			yy_pv = yyv + yypv_index;
			yypvt = yyv + yypvt_index;
		}
		*yy_ps = yy_state;
		*++yy_pv = yyval;

		/*
		** we have a new state - find out what to do
		*/
	yy_newstate:
		if ( ( yy_n = yypact[ yy_state ] ) <= YYFLAG )
			goto yydefault;		/* simple state */
#if YYDEBUG
		/*
		** if debugging, need to mark whether new token grabbed
		*/
		yytmp = yychar < 0;
#endif
		if ( ( yychar < 0 ) && ( ( yychar = YYLEX() ) < 0 ) )
			yychar = 0;		/* reached EOF */
#if YYDEBUG
		if ( yydebug && yytmp )
		{
			register int yy_i;

			printf( "Received token " );
			if ( yychar == 0 )
				printf( "end-of-file\n" );
			else if ( yychar < 0 )
				printf( "-none-\n" );
			else
			{
				for ( yy_i = 0; yytoks[yy_i].t_val >= 0;
					yy_i++ )
				{
					if ( yytoks[yy_i].t_val == yychar )
						break;
				}
				printf( "%s\n", yytoks[yy_i].t_name );
			}
		}
#endif /* YYDEBUG */
		if ( ( ( yy_n += yychar ) < 0 ) || ( yy_n >= YYLAST ) )
			goto yydefault;
		if ( yychk[ yy_n = yyact[ yy_n ] ] == yychar )	/*valid shift*/
		{
			yychar = -1;
			yyval = yylval;
			yy_state = yy_n;
			if ( yyerrflag > 0 )
				yyerrflag--;
			goto yy_stack;
		}

	yydefault:
		if ( ( yy_n = yydef[ yy_state ] ) == -2 )
		{
#if YYDEBUG
			yytmp = yychar < 0;
#endif
			if ( ( yychar < 0 ) && ( ( yychar = YYLEX() ) < 0 ) )
				yychar = 0;		/* reached EOF */
#if YYDEBUG
			if ( yydebug && yytmp )
			{
				register int yy_i;

				printf( "Received token " );
				if ( yychar == 0 )
					printf( "end-of-file\n" );
				else if ( yychar < 0 )
					printf( "-none-\n" );
				else
				{
					for ( yy_i = 0;
						yytoks[yy_i].t_val >= 0;
						yy_i++ )
					{
						if ( yytoks[yy_i].t_val
							== yychar )
						{
							break;
						}
					}
					printf( "%s\n", yytoks[yy_i].t_name );
				}
			}
#endif /* YYDEBUG */
			/*
			** look through exception table
			*/
			{
				register YYCONST int *yyxi = yyexca;

				while ( ( *yyxi != -1 ) ||
					( yyxi[1] != yy_state ) )
				{
					yyxi += 2;
				}
				while ( ( *(yyxi += 2) >= 0 ) &&
					( *yyxi != yychar ) )
					;
				if ( ( yy_n = yyxi[1] ) < 0 )
					YYACCEPT;
			}
		}

		/*
		** check for syntax error
		*/
		if ( yy_n == 0 )	/* have an error */
		{
			/* no worry about speed here! */
			switch ( yyerrflag )
			{
			case 0:		/* new error */
				yyerror( "syntax error" );
				goto skip_init;
			yyerrlab:
				/*
				** get globals into registers.
				** we have a user generated syntax type error
				*/
				yy_pv = yypv;
				yy_ps = yyps;
				yy_state = yystate;
			skip_init:
				yynerrs++;
				/* FALLTHRU */
			case 1:
			case 2:		/* incompletely recovered error */
					/* try again... */
				yyerrflag = 3;
				/*
				** find state where "error" is a legal
				** shift action
				*/
				while ( yy_ps >= yys )
				{
					yy_n = yypact[ *yy_ps ] + YYERRCODE;
					if ( yy_n >= 0 && yy_n < YYLAST &&
						yychk[yyact[yy_n]] == YYERRCODE)					{
						/*
						** simulate shift of "error"
						*/
						yy_state = yyact[ yy_n ];
						goto yy_stack;
					}
					/*
					** current state has no shift on
					** "error", pop stack
					*/
#if YYDEBUG
#	define _POP_ "Error recovery pops state %d, uncovers state %d\n"
					if ( yydebug )
						printf( _POP_, *yy_ps,
							yy_ps[-1] );
#	undef _POP_
#endif
					yy_ps--;
					yy_pv--;
				}
				/*
				** there is no state on stack with "error" as
				** a valid shift.  give up.
				*/
				YYABORT;
			case 3:		/* no shift yet; eat a token */
#if YYDEBUG
				/*
				** if debugging, look up token in list of
				** pairs.  0 and negative shouldn't occur,
				** but since timing doesn't matter when
				** debugging, it doesn't hurt to leave the
				** tests here.
				*/
				if ( yydebug )
				{
					register int yy_i;

					printf( "Error recovery discards " );
					if ( yychar == 0 )
						printf( "token end-of-file\n" );
					else if ( yychar < 0 )
						printf( "token -none-\n" );
					else
					{
						for ( yy_i = 0;
							yytoks[yy_i].t_val >= 0;
							yy_i++ )
						{
							if ( yytoks[yy_i].t_val
								== yychar )
							{
								break;
							}
						}
						printf( "token %s\n",
							yytoks[yy_i].t_name );
					}
				}
#endif /* YYDEBUG */
				if ( yychar == 0 )	/* reached EOF. quit */
					YYABORT;
				yychar = -1;
				goto yy_newstate;
			}
		}/* end if ( yy_n == 0 ) */
		/*
		** reduction by production yy_n
		** put stack tops, etc. so things right after switch
		*/
#if YYDEBUG
		/*
		** if debugging, print the string that is the user's
		** specification of the reduction which is just about
		** to be done.
		*/
		if ( yydebug )
			printf( "Reduce by (%d) \"%s\"\n",
				yy_n, yyreds[ yy_n ] );
#endif
		yytmp = yy_n;			/* value to switch over */
		yypvt = yy_pv;			/* $vars top of value stack */
		/*
		** Look in goto table for next state
		** Sorry about using yy_state here as temporary
		** register variable, but why not, if it works...
		** If yyr2[ yy_n ] doesn't have the low order bit
		** set, then there is no action to be done for
		** this reduction.  So, no saving & unsaving of
		** registers done.  The only difference between the
		** code just after the if and the body of the if is
		** the goto yy_stack in the body.  This way the test
		** can be made before the choice of what to do is needed.
		*/
		{
			/* length of production doubled with extra bit */
			register int yy_len = yyr2[ yy_n ];

			if ( !( yy_len & 01 ) )
			{
				yy_len >>= 1;
				yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
				yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
					*( yy_ps -= yy_len ) + 1;
				if ( yy_state >= YYLAST ||
					yychk[ yy_state =
					yyact[ yy_state ] ] != -yy_n )
				{
					yy_state = yyact[ yypgo[ yy_n ] ];
				}
				goto yy_stack;
			}
			yy_len >>= 1;
			yyval = ( yy_pv -= yy_len )[1];	/* $$ = $1 */
			yy_state = yypgo[ yy_n = yyr1[ yy_n ] ] +
				*( yy_ps -= yy_len ) + 1;
			if ( yy_state >= YYLAST ||
				yychk[ yy_state = yyact[ yy_state ] ] != -yy_n )
			{
				yy_state = yyact[ yypgo[ yy_n ] ];
			}
		}
					/* save until reenter driver code */
		yystate = yy_state;
		yyps = yy_ps;
		yypv = yy_pv;
	}
	/*
	** code supplied by user is placed in this switch
	*/
	switch( yytmp )
	{
		
case 4:
# line 183 "hoc.y"
{ (void)code2(xpop, STOP); return 1; } break;
case 5:
# line 184 "hoc.y"
{ (void)code2(xpop, STOP); return 1; } break;
case 6:
# line 185 "hoc.y"
{ (void)code(STOP); return 1; } break;
case 7:
# line 186 "hoc.y"
{ (void)code2(printtop, STOP); return 1; } break;
case 8:
# line 187 "hoc.y"
{ (void)code2(printtopstring, STOP); return 1; } break;
case 9:
# line 188 "hoc.y"
{ yyerrok; } break;
case 12:
# line 195 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,assign); yyval.inst=yypvt[-0].inst; } break;
case 13:
# line 196 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,const_assign); yyval.inst=yypvt[-0].inst; } break;
case 14:
# line 197 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,addeq); yyval.inst=yypvt[-0].inst; } break;
case 15:
# line 198 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,subeq); yyval.inst=yypvt[-0].inst; } break;
case 16:
# line 199 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,muleq); yyval.inst=yypvt[-0].inst; } break;
case 17:
# line 200 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,diveq); yyval.inst=yypvt[-0].inst; } break;
case 18:
# line 201 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,modeq); yyval.inst=yypvt[-0].inst; } break;
case 19:
# line 202 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,assign); yyval.inst=yypvt[-0].inst; } break;
case 20:
# line 203 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,const_assign); yyval.inst=yypvt[-0].inst; } break;
case 21:
# line 204 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,addeq); yyval.inst=yypvt[-0].inst; } break;
case 22:
# line 205 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,subeq); yyval.inst=yypvt[-0].inst; } break;
case 23:
# line 206 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,muleq); yyval.inst=yypvt[-0].inst; } break;
case 24:
# line 207 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,diveq); yyval.inst=yypvt[-0].inst; } break;
case 25:
# line 208 "hoc.y"
{ (void)code3(varpush,(Inst)yypvt[-2].sym,modeq); yyval.inst=yypvt[-0].inst; } break;
case 26:
# line 209 "hoc.y"
{ defnonly("$"); (void)code2(argassign,(Inst)yypvt[-2].narg); yyval.inst=yypvt[-0].inst;} break;
case 27:
# line 210 "hoc.y"
{ defnonly("$"); (void)code2(argaddeq,(Inst)yypvt[-2].narg); yyval.inst=yypvt[-0].inst;} break;
case 28:
# line 211 "hoc.y"
{ defnonly("$"); (void)code2(argsubeq,(Inst)yypvt[-2].narg); yyval.inst=yypvt[-0].inst;} break;
case 29:
# line 212 "hoc.y"
{ defnonly("$"); (void)code2(argmuleq,(Inst)yypvt[-2].narg); yyval.inst=yypvt[-0].inst;} break;
case 30:
# line 213 "hoc.y"
{ defnonly("$"); (void)code2(argdiveq,(Inst)yypvt[-2].narg); yyval.inst=yypvt[-0].inst;} break;
case 31:
# line 214 "hoc.y"
{ defnonly("$"); (void)code2(argmodeq,(Inst)yypvt[-2].narg); yyval.inst=yypvt[-0].inst;} break;
case 32:
# line 217 "hoc.y"
{(void)code3(varpush,(Inst)yypvt[-2].sym,str_assign); yyval.inst=yypvt[-0].inst; } break;
case 33:
# line 218 "hoc.y"
{(void)code3(varpush,(Inst)yypvt[-2].sym,const_str_assign); yyval.inst=yypvt[-0].inst; } break;
case 34:
# line 219 "hoc.y"
{(void)code3(varpush,(Inst)yypvt[-2].sym,str_assign); yyval.inst=yypvt[-0].inst; } break;
case 35:
# line 220 "hoc.y"
{(void)code3(varpush,(Inst)yypvt[-2].sym,const_str_assign); yyval.inst=yypvt[-0].inst; } break;
case 36:
# line 223 "hoc.y"
{ (void)code(xpop); } break;
case 37:
# line 224 "hoc.y"
{ (void)code(xpop); } break;
case 38:
# line 225 "hoc.y"
{ defnonly("return"); (void)code(procret); } break;
case 39:
# line 227 "hoc.y"
{ defnonly("return"); yyval.inst=yypvt[-0].inst; (void)code(funcret); } break;
case 40:
# line 229 "hoc.y"
{ yyval.inst = yypvt[-3].inst; (void)code3(call, (Inst)yypvt[-4].sym, (Inst)yypvt[-1].narg); } break;
case 41:
# line 230 "hoc.y"
{ yyval.inst = yypvt[-0].inst; } break;
case 42:
# line 231 "hoc.y"
{ yyval.inst = yypvt[-0].inst; } break;
case 43:
# line 232 "hoc.y"
{ yyval.inst = yypvt[-0].inst; (void)code(prnl); } break;
case 44:
# line 233 "hoc.y"
{
		(yypvt[-5].inst)[1] = (Inst)yypvt[-1].inst;	/* body of loop */
		(yypvt[-5].inst)[2] = (Inst)yypvt[-0].inst; } break;
case 45:
# line 236 "hoc.y"
{
		(yypvt[-9].inst)[1] = (Inst)yypvt[-5].inst;	/* condition */
		(yypvt[-9].inst)[2] = (Inst)yypvt[-3].inst;	/* post loop */
		(yypvt[-9].inst)[3] = (Inst)yypvt[-1].inst;	/* body of loop */
		(yypvt[-9].inst)[4] = (Inst)yypvt[-0].inst; } break;
case 46:
# line 241 "hoc.y"
{	/* else-less if */
		(yypvt[-5].inst)[1] = (Inst)yypvt[-1].inst;	/* thenpart */
		(yypvt[-5].inst)[3] = (Inst)yypvt[-0].inst; } break;
case 47:
# line 244 "hoc.y"
{	/* if with else */
		(yypvt[-8].inst)[1] = (Inst)yypvt[-4].inst;	/* thenpart */
		(yypvt[-8].inst)[2] = (Inst)yypvt[-1].inst;	/* elsepart */
		(yypvt[-8].inst)[3] = (Inst)yypvt[-0].inst; } break;
case 48:
# line 248 "hoc.y"
{ yyval.inst = yypvt[-1].inst; } break;
case 49:
# line 250 "hoc.y"
{ (void)code(STOP); } break;
case 50:
# line 252 "hoc.y"
{ yyval.inst = code3(whilecode,STOP,STOP); } break;
case 51:
# line 254 "hoc.y"
{ yyval.inst = code(forcode); (void)code4(STOP,STOP,STOP,STOP); } break;
case 52:
# line 256 "hoc.y"
{ yyval.inst = code(ifcode); (void)code3(STOP,STOP,STOP); } break;
case 53:
# line 258 "hoc.y"
{ yyval.inst = progp; } break;
case 54:
# line 260 "hoc.y"
{ (void)code(STOP); yyval.inst = progp; } break;
case 55:
# line 262 "hoc.y"
{ yyval.inst = progp; } break;
case 58:
# line 267 "hoc.y"
{ yyval.inst = code2(const_str_push, (Inst)yypvt[-0].sym); } break;
case 59:
# line 268 "hoc.y"
{ yyval.inst = code3(varpush, (Inst)yypvt[-0].sym, streval); } break;
case 61:
# line 270 "hoc.y"
{ yyval.inst = yypvt[-1].inst; } break;
case 62:
# line 271 "hoc.y"
{ (void)code(hexfp); } break;
case 63:
# line 272 "hoc.y"
{ (void)code(hexint); } break;
case 64:
# line 273 "hoc.y"
{ (void)code(numtostr); } break;
case 65:
# line 274 "hoc.y"
{ yyval.inst = code2(varread, (Inst)yypvt[-1].sym); } break;
case 66:
# line 275 "hoc.y"
{ (void)code2(strbltin0, (Inst)yypvt[-2].sym->u.ptr0); } break;
case 67:
# line 276 "hoc.y"
{ yyval.inst = yypvt[-1].inst; (void)code2(strbltin1, (Inst)yypvt[-3].sym->u.ptr1); } break;
case 68:
# line 277 "hoc.y"
{ yyval.inst = yypvt[-3].inst; (void)code2(strbltin2, (Inst)yypvt[-5].sym->u.ptr2); } break;
case 69:
# line 278 "hoc.y"
{ (void)code(str_strftime); yyval.inst = yypvt[-3].inst; } break;
case 70:
# line 279 "hoc.y"
{ (void)code(str_substr); yyval.inst = yypvt[-5].inst; } break;
case 72:
# line 283 "hoc.y"
{ (void)code(str_concat_ss); } break;
case 73:
# line 284 "hoc.y"
{ (void)code(str_concat_sn); } break;
case 74:
# line 290 "hoc.y"
{ (void)code(str_concat_ns); } break;
case 75:
# line 293 "hoc.y"
{ yyval.inst = code2(constpush, (Inst)yypvt[-0].sym); } break;
case 76:
# line 294 "hoc.y"
{ yyval.inst = code3(varpush, (Inst)yypvt[-0].sym, eval); } break;
case 77:
# line 295 "hoc.y"
{ defnonly("$"); yyval.inst = code2(arg, (Inst)yypvt[-0].narg); } break;
case 79:
# line 298 "hoc.y"
{ yyval.inst = yypvt[-3].inst; (void)code3(call,(Inst)yypvt[-4].sym,(Inst)yypvt[-1].narg); } break;
case 80:
# line 299 "hoc.y"
{ yyval.inst = code2(varread, (Inst)yypvt[-1].sym); } break;
case 81:
# line 300 "hoc.y"
{ yyval.inst = code2(abort_user, (Inst)yypvt[-1].sym); } break;
case 82:
# line 301 "hoc.y"
{ (void)code(hex); } break;
case 83:
# line 302 "hoc.y"
{ (void)code2(bltin0, (Inst)yypvt[-2].sym->u.ptr0); } break;
case 84:
# line 303 "hoc.y"
{ yyval.inst = yypvt[-1].inst; (void)code2(bltin1, (Inst)yypvt[-3].sym->u.ptr1); } break;
case 85:
# line 304 "hoc.y"
{ yyval.inst = yypvt[-3].inst; (void)code2(bltin2, (Inst)yypvt[-5].sym->u.ptr2); } break;
case 86:
# line 305 "hoc.y"
{ (void)code(str_index); yyval.inst = yypvt[-1].inst; } break;
case 87:
# line 306 "hoc.y"
{ (void)code(str_length); yyval.inst = yypvt[-1].inst; } break;
case 88:
# line 307 "hoc.y"
{ (void)code(str_to_num); yyval.inst = yypvt[-1].inst; } break;
case 89:
# line 308 "hoc.y"
{ yyval.inst = yypvt[-1].inst; } break;
case 90:
# line 309 "hoc.y"
{ (void)code(add); } break;
case 91:
# line 310 "hoc.y"
{ (void)code(sub); } break;
case 92:
# line 311 "hoc.y"
{ (void)code(mul); } break;
case 93:
# line 312 "hoc.y"
{ (void)code(divop); } break;
case 94:
# line 313 "hoc.y"
{ (void)code(mod); } break;
case 95:
# line 314 "hoc.y"
{ (void)code(power); } break;
case 96:
# line 315 "hoc.y"
{ yyval.inst=yypvt[-0].inst; (void)code(negate); } break;
case 97:
# line 316 "hoc.y"
{ yyval.inst=yypvt[-0].inst; (void)code(noop); } break;
case 98:
# line 317 "hoc.y"
{ (void)code(gt); } break;
case 99:
# line 318 "hoc.y"
{ (void)code(ge); } break;
case 100:
# line 319 "hoc.y"
{ (void)code(lt); } break;
case 101:
# line 320 "hoc.y"
{ (void)code(le); } break;
case 102:
# line 321 "hoc.y"
{ (void)code(eq); } break;
case 103:
# line 322 "hoc.y"
{ (void)code(ne); } break;
case 104:
# line 323 "hoc.y"
{ (void)code(And); } break;
case 105:
# line 324 "hoc.y"
{ (void)code(Or); } break;
case 106:
# line 325 "hoc.y"
{ yyval.inst = yypvt[-0].inst; (void)code(Not); } break;
case 107:
# line 326 "hoc.y"
{ yyval.inst = code2(preinc,(Inst)yypvt[-0].sym); } break;
case 108:
# line 327 "hoc.y"
{ yyval.inst = code2(predec,(Inst)yypvt[-0].sym); } break;
case 109:
# line 328 "hoc.y"
{ yyval.inst = code2(postinc,(Inst)yypvt[-1].sym); } break;
case 110:
# line 329 "hoc.y"
{ yyval.inst = code2(postdec,(Inst)yypvt[-1].sym); } break;
case 111:
# line 330 "hoc.y"
{ (void)code(str_gt); } break;
case 112:
# line 331 "hoc.y"
{ (void)code(str_ge); } break;
case 113:
# line 332 "hoc.y"
{ (void)code(str_lt); } break;
case 114:
# line 333 "hoc.y"
{ (void)code(str_le); } break;
case 115:
# line 334 "hoc.y"
{ (void)code(str_eq); } break;
case 116:
# line 335 "hoc.y"
{ (void)code(str_ne); } break;
case 117:
# line 337 "hoc.y"
{ (void)code(prexpr); } break;
case 118:
# line 338 "hoc.y"
{ (void)code(prstr); } break;
case 119:
# line 339 "hoc.y"
{ (void)code(prexpr); } break;
case 120:
# line 340 "hoc.y"
{ (void)code(prstr); } break;
case 121:
# line 342 "hoc.y"
{ yypvt[-0].sym->type=FUNCTION; indef=1; } break;
case 122:
# line 343 "hoc.y"
{ (void)code(procret); define(yypvt[-4].sym); indef=0; } break;
case 123:
# line 344 "hoc.y"
{ yypvt[-0].sym->type=PROCEDURE; indef=1; } break;
case 124:
# line 345 "hoc.y"
{ (void)code(procret); define(yypvt[-4].sym); indef=0; } break;
case 128:
# line 351 "hoc.y"
{ yyval.narg = 0; } break;
case 129:
# line 352 "hoc.y"
{ yyval.narg = 1; } break;
case 130:
# line 353 "hoc.y"
{ yyval.narg = 1; } break;
case 131:
# line 354 "hoc.y"
{ yyval.narg = yypvt[-2].narg + 1; } break;
case 132:
# line 355 "hoc.y"
{ yyval.narg = yypvt[-2].narg + 1; } break;
# line	531 "/usr/ccs/bin/yaccpar"
	}
	goto yystack;		/* reset registers in driver code */
}

