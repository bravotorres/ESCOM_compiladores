
typedef union
#ifdef __cplusplus
	YYSTYPE
#endif
 {
	Symbol	*sym;	/* symbol table pointer */
	Inst	*inst;	/* machine instruction */
	long	narg;	/* number of arguments */
} YYSTYPE;
extern YYSTYPE yylval;
# define NUMBER 257
# define STRING 258
# define PRINT 259
# define VAR 260
# define UNDEF 261
# define WHILE 262
# define FOR 263
# define IF 264
# define ELSE 265
# define FUNCTION 266
# define PROCEDURE 267
# define RETURN 268
# define FUNC 269
# define PROC 270
# define READ 271
# define ABORT 272
# define BLTIN0 273
# define BLTIN1 274
# define BLTIN2 275
# define HEX 276
# define HEXFP 277
# define HEXINT 278
# define INDEX 279
# define LENGTH 280
# define NUMTOSTR 281
# define PRINTF 282
# define PRINTLN 283
# define STRBLTIN0 284
# define STRBLTIN1 285
# define STRBLTIN2 286
# define STRVAR 287
# define STRFTIME 288
# define STRTONUM 289
# define SUBSTR 290
# define ARG 291
# define ADDEQ 292
# define SUBEQ 293
# define MULEQ 294
# define DIVEQ 295
# define MODEQ 296
# define CONSTEQ 297
# define OR 298
# define AND 299
# define GT 300
# define GE 301
# define LT 302
# define LE 303
# define EQ 304
# define NE 305
# define UNARYMINUS 306
# define UNARYPLUS 307
# define NOT 308
# define INC 309
# define DEC 310
