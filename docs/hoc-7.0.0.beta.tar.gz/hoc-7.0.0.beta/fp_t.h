#if !defined(FP_T_H)
#define FP_T_H

typedef double fp_t;
#endif /* !defined(FP_T_H) */
