#include "hoc.h"

#if defined(HAVE_FLOAT_H)
#include <float.h>
#endif

#if defined(HAVE_MATH_H)
#include <math.h>
#endif

#if defined(HAVE_STRING_H)
#include <string.h>
#endif

#if defined(HAVE_STDIO_H)
#include <stdio.h>			/* only for readline.h */
#endif

#if defined(HAVE_TIME_H)
#include <time.h>
#endif

#include "y.tab.h"			/* NB: must come BEFORE readline.h!  */
#include "readline.h"			/* only for MAX_PUSHBACK and MAX_TOKEN */

static void	init_consts ARGS((void));

static struct {		/* Keywords */
	const char	*name;
	int	kval;
} keywords[] = {
	"proc",		PROC,
	"func",		FUNC,
	"return",	RETURN,
	"if",		IF,
	"else",		ELSE,
	"while",	WHILE,
	"for",		FOR,
	"print",	PRINT,
	"read",		READ,
	"__hex",	HEX,		/* new for debugging and prototyping */
	"abort",	ABORT,		/* new */
	"hexfp",	HEXFP,		/* new */
	"hexint",	HEXINT,		/* new */
	"index",	INDEX,		/* new */
	"length",	LENGTH,		/* new */
	"number",	STRTONUM,	/* new */
	"printf",	PRINTF,		/* new */
	"println",	PRINTLN,	/* new */
	"strftime",	STRFTIME,	/* new */
	"string",	NUMTOSTR,	/* new */
	"substr",	SUBSTR,		/* new */
	0,		0,
};

static struct {		/* Constants */
	const char *name;
	fp_t cval;
	int immutable;
} consts[] = {
	"PI",	 3.141592653589793238462643383279502884197e+00, 1,
	"E",	 2.718281828459045235360287471352662497757e+00, 1,
	"GAMMA", 0.5772156649015328606065120900824024310422e+00, 1,	/* Euler */
	"DEG",	57.29577951308232087679815481410517033240e+00, 1,	/* deg/radian */
	"PHI",   1.618033988749894848204586834365638117720e+00, 1,  	/* golden ratio */
	"PREC",	17, 0,			/* output precision (replaced at run time) */
			/* From David Matula, ``In-and-Out Conversions'',
			Comm. ACM, 11(1) 47--50, January, 1968): need at least
			(N/(log_b 10) + 1) decimal digits to correctly represent
			an N-digit base-b number in base 10.  For IEEE 754
			fp_t precision, b = 2 and N = 53, so we need
			ceil(53/(log2(10)) + 1) = ceil(16.95) = 17 decimal
			digits. */
	"CATALAN",	0.9159655941772190150546035149323841107741e+00, 1, /* Catalan's constant */
	"INF",		0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"Inf",		0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"Infinity",	0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"NAN",		0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"NaN",		0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"QNAN",		0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"QNaN",		0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"SNAN",		0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"SNaN",		0.0, 1,		/* replaced at run time if HAVE_IEEE_754 */
	"MAXNORMAL",	0.0, 1,		/* replaced at run time */
	"MINNORMAL",	0.0, 1,		/* replaced at run time */
	"MINSUBNORMAL",	0.0, 1,		/* replaced at run time */

	/* Compile-time dimension constants */
	"__MAX_NAME__",		MAX_NAME, 1,
	"__MAX_PUSHBACK__",	MAX_PUSHBACK, 1,
	"__MAX_STRING__",	MAX_STRING, 1,
	"__MAX_TOKEN__",	MAX_TOKEN, 1,

	(const char*)NULL,	 0.0, 0,
};

static struct {		/* Numeric built-ins with zero arguments */
	const char *name;
	fp_t	(*func) ARGS((void));
} builtins_0[] = {
	"rand",		Rand,
	"second",	Second,
	"systime",	Systime,
	(const char*)NULL, (F0_t)NULL,
};


static struct {		/* Numeric built-ins with one argument */
	const char *name;
	fp_t	(*func) ARGS((fp_t));
} builtins_1[] = {
	/* Please keep these groups sorted alphabetically, ignoring lettercase */
	/* Functions from Standard C */
	"abs",		Abs,
	"acos",		Acos,		/* checks range */
	"asin",		Asin,		/* checks range */
	"atan",		Atan,
	"ceil",		Ceil,
	"cos",		Cos,
	"cosh",		Cosh,		/* checks range */
	"exp",		Exp,		/* checks range */
	"floor",	Floor,
	"gamma",	Gamma,		/* checks range */
	"int",		Integer,
	"ln",		Log,		/* checks range */
	"log",		Log,		/* checks range */
	"nint",		Nint,
	"sin",		Sin,
	"sinh",		Sinh,		/* checks range */
	"sqrt",		Sqrt,		/* checks range */
	"tan",		Tan,
	"tanh",		Tanh,

	/* Nonstandard, but commonly available, functions */

	"erf",		Erf,
	"erfc",		Erfc,

	/* Additional functions */

	"acosh",	Acosh,
	"asinh",	Asinh,
	"atanh",	Atanh,
	"cbrt",		Cbrt,
	"cpulimit",	CPULimit,
	"expm1",	Expm1,
	"exponent",	Exponent,
	"ilogb",	Ilogb,
	"isfinite",	IsFinite,
	"isinf",	IsInf,
	"isnan",	IsNaN,
	"isnormal",	IsNormal,
	"isqnan",	IsQNaN,
	"issnan",	IsSNaN,
	"issubnormal",	IsSubnormal,
	"J0",		J0,
	"J1",		J1,
	"lgamma", 	Lgamma,
	"log10",	Log10,		/* checks range */
	"log1p",	Log1p,
	"log2",		Log2,		/* checks range */
	"macheps",	Macheps,
	"randl",	Randl,
	"rint",		Rint,
	"rsqrt",	Rsqrt,
	"setrand",	SetRandSeed,
	"significand",	Significand,
	"trunc",	Trunc,
	"Y0",		Y0,
	"Y1",		Y1,

	(const char*)NULL, (F1_t)NULL,
};

static struct {		/* Numeric built-ins with two arguments */
	const char *name;
	fp_t	(*func) ARGS((fp_t, fp_t));
} builtins_2[] = {
	"copysign",	Copysign,
	"fmod",		Fmod,
	"hypot",	Hypot,
	"Jn",		Jn,
	"ldexp",	Ldexp,
	"nearest",	Nearest,
	"nextafter",	Nextafter,
	"randint",	RandInt,
	"remainder",	Remainder,
	"scalb",	Scalb,
	"Yn",		Yn,

	(const char*)NULL, (F2_t)NULL,
};

static struct {		/* String built-ins with zero arguments */
	const char *name;
	const char *(*func) ARGS((void));
} strbuiltins_0[] = {
	"logoff",	Logoff,
	"logon",	Logon,
	"now",		Now,

	(const char*)NULL, (SF0_t)NULL,
};

static struct {		/* String built-ins with one argument */
	const char *name;
	const char *(*func) ARGS((const char *));
} strbuiltins_1[] = {
	"eval",		Evalcommands,
	"getenv",	Getenv,
	"load",		Load,
	"logfile",	Logfile,
	"printenv",	Printenv,
	"tolower",	Tolower,
	"toupper",	Toupper,
	"who",		Who,

	(const char*)NULL, (SF1_t)NULL,
};

static struct {		/* String built-ins with two arguments */
	const char *name;
	const char *(*func) ARGS((const char *, const char *));
} strbuiltins_2[] = {
	"putenv",	Putenv,
	"save",		Save,

	(const char*)NULL, (SF2_t)NULL,
};

#define STREQUAL(a,b)	(strcmp(a,b) == 0)

int
default_precision(void)
{	/* Return the default output precision */
#if defined(DBL_MANT_DIG) && defined(FLT_RADIX)
	return ((int)ceil(DBL_MANT_DIG/(log(10.0)/log((fp_t)FLT_RADIX)) + 1));
			/* see Matula reference in consts[] initializer above */
#else
	return (17);	/* suitable for IEEE 754 64-bit fp_t */
#endif
}

int
get_precision(void)
{	/* Return the current output precision */
	Symbol *s;
	int precision;

	s = lookup("PREC");
	if (s == (Symbol*)NULL)
		(void)set_precision((precision = default_precision(), precision));
	else
		precision = (int)s->u.val;
	return (precision);
}

int
set_precision(int new_precision)
{
	/* Set the new floating-point precision to new_precision, and
	return the old one. */
	int old_precision;

	old_precision = get_precision();

	/* Guarantee reasonable values of PREC: keep in range [0..35]
	   (35 is adequate for 128-bit IEEE 754 floating point. */
	if (new_precision < 0)
		new_precision = 0;
	else if (new_precision > 35)
		new_precision = 35;
	lookup("PREC")->u.val = (fp_t)new_precision;
	return (old_precision);
}

void
init_builtins(void)	/* install constants and built-ins in table */
{
	int i;
	Symbol *s;

	for (i = 0; keywords[i].name; i++)
		(void)install(keywords[i].name, keywords[i].kval, 0.0);
	(void)install_number("_", 0.0);	/* last numeric result */
	(void)install_string("__","");	/* last string result */

	init_consts();
	for (i = 0; consts[i].name; i++)
	{
		if (consts[i].immutable)
			(void)install_const_number(consts[i].name, consts[i].cval);
		else
			(void)install(consts[i].name, VAR, consts[i].cval);
	}
	for (i = 0; builtins_0[i].name; i++) {
		s = install(builtins_0[i].name, BLTIN0, 0.0);
		s->u.ptr0 = builtins_0[i].func;
	}

	for (i = 0; builtins_1[i].name; i++) {
		s = install(builtins_1[i].name, BLTIN1, 0.0);
		s->u.ptr1 = builtins_1[i].func;
	}

	for (i = 0; builtins_2[i].name; i++) {
		s = install(builtins_2[i].name, BLTIN2, 0.0);
		s->u.ptr2 = builtins_2[i].func;
	}

	for (i = 0; strbuiltins_0[i].name; i++) {
		s = install(strbuiltins_0[i].name, STRBLTIN0, 0.0);
		s->u.sptr0 = strbuiltins_0[i].func;
	}

	for (i = 0; strbuiltins_1[i].name; i++) {
		s = install(strbuiltins_1[i].name, STRBLTIN1, 0.0);
		s->u.sptr1 = strbuiltins_1[i].func;
	}

	for (i = 0; strbuiltins_2[i].name; i++) {
		s = install(strbuiltins_2[i].name, STRBLTIN2, 0.0);
		s->u.sptr2 = strbuiltins_2[i].func;
	}

	update_number("__CPU_LIMIT__", Infinity());

#if defined(HAVE_TIME_H) && defined(HAVE_STRFTIME)
	{
		char datestamp[sizeof("MMM DD YYYY") + 1];
		char timestamp[sizeof("HH:MM:SS") + 1];

		time_t now;

		(void)time(&now);

		(void)strftime(datestamp, sizeof(datestamp), "%b %d %Y", localtime(&now));
		(void)strftime(timestamp, sizeof(datestamp), "%H:%M:%S", localtime(&now));

		if (datestamp[4] == '0')
			datestamp[4] = ' '; /* Standard C requires leading zero as blank */

		(void)install_const_string("__DATE__", &datestamp[0]);
		(void)install_const_string("__TIME__", &timestamp[0]);
	}
#else
	/* Ensure that __DATE__ and __TIME__ have dummy values when we
	   cannot get correct values, so that the variables are
	   guaranteed to be available in user code. */
	(void)install_const_string("__DATE__", "MMM DD YYYY");
	(void)install_const_string("__TIME__", "HH:MM:SS");
#endif
}

static void
init_consts(void)
{
	int i;
	for (i = 0; consts[i].name; i++)
	{
		if (STREQUAL(consts[i].name, "NAN") ||
		    STREQUAL(consts[i].name, "NaN"))
			consts[i].cval = NaN();
		else if (STREQUAL(consts[i].name, "QNAN") ||
		    STREQUAL(consts[i].name, "QNaN"))
			consts[i].cval = QNaN();
		else if (STREQUAL(consts[i].name, "SNAN") ||
		    STREQUAL(consts[i].name, "SNaN"))
			consts[i].cval = SNaN();
		else if (STREQUAL(consts[i].name, "INF") ||
			 STREQUAL(consts[i].name, "Inf") ||
			 STREQUAL(consts[i].name, "Infinity"))
			consts[i].cval = Infinity();
		else if (STREQUAL(consts[i].name, "PREC"))
			consts[i].cval = default_precision();
		else if (STREQUAL(consts[i].name, "MAXNORMAL"))
			consts[i].cval = MaxNormal();
		else if (STREQUAL(consts[i].name, "MINNORMAL"))
			consts[i].cval = MinNormal();
		else if (STREQUAL(consts[i].name, "MINSUBNORMAL"))
			consts[i].cval = MinSubnormal();
	}
}
