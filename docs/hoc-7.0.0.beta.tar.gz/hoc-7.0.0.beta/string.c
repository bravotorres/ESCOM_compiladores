#include "hoc.h"
#include "y.tab.h"

#if defined(HAVE_CTYPE_H)
#include <ctype.h>
#endif

#if defined(HAVE_MATH_H)
#include <math.h>
#endif

#if defined(HAVE_STDIO_H)
#include <stdio.h>
#endif

#if defined(HAVE_STRING_H)
#include <string.h>
#endif

#if defined(HAVE_TIME_H)
#include <time.h>
#endif

#if defined(HAVE_UNISTD_H)
#include <unistd.h>
#endif

#include "readline.h"

#if !defined(F_OK)
#define	F_OK	0		/* Test for file existence: access(filename, F_OK) */
#endif

#define elementsof(x)	(sizeof(x)/sizeof(x[0]))

#define FILE_EXISTS(filename) ((int)access((const char*)(filename), F_OK) == 0)

FILE *fplog = (FILE*)NULL;

extern const char *current_filename;	/* defined in hoc.y */
extern char **environ;			/* defined in run-time library */
extern FILE *fin;			/* defined in hoc.y */
extern int load_enabled;		/* defined in hoc.y */
extern int logfile_enabled;		/* defined in hoc.y */
extern int save_enabled;		/* defined in hoc.y */

static void 		save_symbols ARGS((FILE *, const char *));
EXTERN int		cmpsym ARGS((const void *, const void *));

#if defined(__cplusplus) || defined(c_plusplus)
extern "C"
#endif
int
cmpstr(const void *v1, const void *v2)
{
	return (strcmp(*(const char **)v1,*(const char **)v2));
}

const char *
concat2(const char *s, const char *t)
{
	if (s == (const char *)NULL)
		s = "";
	if (t == (const char *)NULL)
		t = "";
	return ((const char*)strcat(strcpy((char*)emalloc(strlen(s) + strlen(t) + 1), s), t));
}

const char *
concat3(const char *s, const char *t, const char *u)
{
	if (s == (const char *)NULL)
		s = "";
	if (t == (const char *)NULL)
		t = "";
	if (u == (const char *)NULL)
		u = "";
	return ((const char*)strcat(strcat(strcpy((char*)emalloc(strlen(s) + strlen(t) + strlen(u) + 1), s), t), u));
}

const char *
concat4(const char *s, const char *t, const char *u, const char *v)
{
	if (s == (const char *)NULL)
		s = "";
	if (t == (const char *)NULL)
		t = "";
	if (u == (const char *)NULL)
		u = "";
	if (v == (const char *)NULL)
		v = "";
	return ((const char*)strcat(strcat(strcat(strcpy((char*)emalloc(strlen(s) + strlen(t) + strlen(u) + strlen(v) + 1), s), t), u), v));
}

const char *
concat5(const char *s, const char *t, const char *u, const char *v, const char *w)
{
	if (s == (const char *)NULL)
		s = "";
	if (t == (const char *)NULL)
		t = "";
	if (u == (const char *)NULL)
		u = "";
	if (v == (const char *)NULL)
		v = "";
	if (w == (const char *)NULL)
		w = "";
	return ((const char*)strcat(strcat(strcat(strcat(strcpy((char*)emalloc(strlen(s) + strlen(t) + strlen(u) + strlen(v) + strlen(w) + 1), s), t), u), v), w));
}

int
decval(int c)
{	/* return the decimal value of c, or 01 if not decimal */
	/* All current characters sets (ASCII, EBCDIC, ISO8859-n,
	   ISO10646, Unicode) have consecutive decimal digits, so this
	   code is portable. */
	if (('0' <= c) && (c <= '9'))
		return ((int)(c - '0'));
	else
		return (-1);
}

const char *
Getenv(const char *envvar)
{	/* Return the value of environment variable envvar, as a new
	   string (empty if envvar was not defined, or was empty).
	   The dupstr() call is necessary because at least two UNIX
	   platforms (Apple Darwin (MacOS X) and FreeBSD) use an
	   overwrite-in-place-when-possible algorithm in putenv(). */
	const char *p;

	p = (const char *)getenv(envvar);
	if (p == (const char *)NULL)
		p = "";
	return (dupstr(p));
}

int
hexval(int c)
{	/* return the hexadecimal value of c, or -1 if not hexadecimal */
	/* All current characters sets (ASCII, EBCDIC, ISO8859-n,
	   ISO10646, Unicode) have consecutive decimal digits and
	   consecutive letters A-F, so this code is portable. */
	if (('0' <= c) && (c <= '9'))
		return ((int)(c - '0'));
	else if (('a' <= c) && (c <= 'f'))
		return ((int)((c - 'a') + 10));
	else if (('A' <= c) && (c <= 'F'))
		return ((int)((c - 'A') + 10));
	else
		return (-1);
}

const char *
Inf_string(fp_t x)
{
	return ((x < 0) ? "-Inf" : "+Inf");
}

const char *
Load(const char *filename)
{
	FILE *old_fin;
	const char *old_current_filename;

	if (filename == (const char*)NULL) /* should never happen, but keeps lint happy */
		return ("");

	if (!load_enabled)
		return (msg_translate("load() command is disabled"));

	old_fin = fin;
	old_current_filename = dupstr(current_filename);
	fin = fopen(filename,"r");
	if (fin == (FILE*)NULL)
	{
		(void)fprintf(stderr,  msg_translate("%s: can't open %s\n"),
			      progname, filename);
		fin = old_fin;
		return(msg_translate("load() open failed"));
	}
	irl_push_input();
	set_filename(filename);
	run();
	set_filename(old_current_filename);
	irl_pop_input();
	efree((void*)old_current_filename);
	fin = old_fin;
	return ("");
}

const char *
Logfile(const char *filename)
{	/* close any open log file, open new one (error if it exists, for security reasons) */
	static const char *old_logfilename = "";

	if (filename == (char*)NULL)
		return ("");

	if (!logfile_enabled)
		return (msg_translate("logfile() command is disabled"));

	if (FILE_EXISTS(filename) &&
	    (strcmp(filename,"/dev/tty") != 0) &&
	    (strcmp(filename,"") != 0))
		execerror("logfile() will not overwrite existing file", filename);

	if ((fplog != (FILE*)NULL) && (strcmp(old_logfilename,"") != 0))
		(void)fclose(fplog);

	if (strcmp(filename,"") == 0)
		fplog = stdout;
	else
		fplog = fopen(filename,"w");

	if (fplog == (FILE*)NULL)
		execerror("logfile() open failed", filename);

	old_logfilename = dupstr(filename);
	logfile_enabled = 1;
	return ("");
}

const char *
Logoff(void)
{
	logfile_enabled = 0;
	return ("");
}

const char *
Logon(void)
{
	logfile_enabled = 1;
	return ("");
}

const char *
NaN_string(fp_t x)
{
	if (IsSNaN(x) && !IsQNaN(x))
		return ((Copysign(1.0,x) * Copysign(1.0,NaN()) == -1.0) ? "-SNaN" : "+SNaN");
	else if (IsQNaN(x) && !IsSNaN(x))
		return ((Copysign(1.0,x) * Copysign(1.0,NaN()) == -1.0) ? "-QNaN" : "+QNaN");
	else if (IsNaN(x))
		return ((Copysign(1.0,x) * Copysign(1.0,NaN()) == -1.0) ? "-NaN" : "+NaN");
	else
		return ((const char *)NULL);
}

const char *
Printenv(const char *prefix)
{
	char *equals;
	int len;
	size_t len_prefix;
	int max_name_width;
	size_t n;
	char **p;
	char **sorted_environ;

	if (prefix == (const char *)NULL)
		prefix = "";
	len_prefix = strlen(prefix);

	max_name_width = 0;
	for (n = 0, p = environ; (*p != (char *)NULL); ++p)
	{
		++n;			/* find out how many we need */
		if (strncmp((const char *)*p,prefix,len_prefix) == 0)
		{
			len = (int)(strchr(*p,'=') - *p);
			if (max_name_width < len)
				max_name_width = len;
		}
	}

	sorted_environ = (char **)emalloc((n + 1) * sizeof(char *));
	for (n = 0, p = environ; (*p != (char *)NULL); ++p)
		sorted_environ[n++] = *p;
	sorted_environ[n] = (char *)NULL;

	qsort(sorted_environ, n, sizeof(char *), cmpstr);

	for (p = sorted_environ; (*p != (char *)NULL); ++p)
	{
		if (strncmp(*p,prefix,len_prefix) == 0)
		{
			equals = strchr(*p,'=');
			*equals = '\0';
			prtext2(*p, max_name_width);
			prtext("\t= \"");
			prtext(equals + 1);
			prtext("\"\n");
			*equals = '=';
		}
	}

	efree((void*)sorted_environ);

	return ("");
}

static const char *
protect(const char *s)
{	/* return a copy of s with all nonprintable characters protected */
	char *protected_s;
	char *p;
	const char *q;
	static const char inputtab[]  = "\a\b\f\n\r\t\v\033";
	static const char outputtab[] = "abfnrtvE";

	protected_s = (char*)emalloc(4*strlen(s) + 1); /* for \ooo worst-case expansion */
	for (p = protected_s; *s; ++s)
	{
		if ((q = strchr(inputtab,*s), q) != (const char*)NULL)
		{
			(void)sprintf(p, "\\%c", (unsigned int)UC(outputtab[q-inputtab]));
			p += 2;
		}
		else if ((*s == '\\') || (*s == '"'))
		{
			(void)sprintf(p, "\\%c", (unsigned int)UC(*s));
			p += 2;
		}
		else if (isprint(*s))
			*p++ = *s;
		else
		{
			(void)sprintf(p, "\\%03o", (unsigned int)UC(*s));
			p += 4;
		}
	}
	*p = '\0';
	return ((const char*)protected_s);
}

const char *
Putenv(const char *envvar, const char *newval)
{
	const char *oldval;

	oldval = Getenv(envvar);	/* NB: NOT getenv()! ... see Getenv() comments */
	(void)putenv((char*)concat3(envvar,"=",newval));
	return (oldval);
}

const char *
Save(const char *filename, const char *prefix)
{
	/* open new save file (error if it exists, for security reasons) */
	FILE *fpsave;

	if (filename == (char*)NULL)
		return ("");

	if (!save_enabled)
		return (msg_translate("save() command is disabled"));

	if (FILE_EXISTS(filename) && (strcmp(filename,"/dev/tty") != 0))
		execerror("save() will not overwrite existing file", filename);
	if (strcmp(filename,"") == 0)
		fpsave = stdout;
	else
		fpsave = fopen(filename,"w");
	if (fpsave == (FILE*)NULL)
		execerror("save() open failed", filename);

	if (prefix == (const char*)NULL)
		prefix = "";

	(void)fprintf(fpsave, "### -*-hoc-*-\n");
	(void)fprintf(fpsave, "### ====================================================================\n");
	(void)fprintf(fpsave, msg_translate("### This is hoc save file %s\n"), filename);
	if (*prefix)
		(void)fprintf(fpsave,
			      msg_translate("### WARNING: This file contains only symbols prefixed by \"%s\"\n"),
			      prefix);
	(void)fprintf(fpsave, msg_translate("### Creator:           %s version %s [%s]\n"),
		      PACKAGE_NAME, PACKAGE_VERSION, PACKAGE_DATE);
	(void)fprintf(fpsave, msg_translate("### CreationDate:      %s\n"), Now());
	(void)fprintf(fpsave, msg_translate("### PackageBugReports: %s\n"), PACKAGE_BUGREPORT);
	(void)fprintf(fpsave, "### ====================================================================\n\n");
	save_symbols(fpsave,prefix);
	if (strcmp(filename,"") != 0)
		(void)fclose(fpsave);
	return ("");
}

static void
save_symbols(FILE *fpsave, const char *prefix)
{
	Symbol **symtab;
	Symbol *sp;
	const char *p;
	fp_t d;
	int old_precision;
	size_t k;
	size_t max_symbols;
	size_t n_symtab;

	old_precision = get_precision();
	(void)set_precision(default_precision());

	max_symbols = 0;
	for (sp = first_symbol(); sp != (Symbol *)NULL; sp = next_symbol())
		max_symbols++;

	symtab = (Symbol**)emalloc(max_symbols * sizeof(Symbol*));

	/* First build a table of matching symbols that we can later sort */
	for (n_symtab = 0, sp = first_symbol(); sp != (Symbol *)NULL; sp = next_symbol())
	{
		if ((sp->name != (const char*)NULL) &&
		    *sp->name &&
		    (n_symtab < max_symbols) &&
		    !is_hidden(sp->name,prefix) &&
		    is_match(sp->name,prefix))
			symtab[n_symtab++] = sp;
	}

	qsort(symtab, n_symtab, sizeof(Symbol*), cmpsym);
	for (k = 0; k < n_symtab; ++k)
	{
		if (strncmp("__",symtab[k]->name,2) == 0)
			continue;	/* never save internal symbols! */

		/* TO-DO: What we really need here is a test for
		   predefined, NOT immutable.  However, the symbol
		   table does not yet contain that information, so for
		   now, we just assume immutable means built-in, which
		   is not true in general. */
		if (symtab[k]->immutable)
			continue;	/* never save immutable symbols! */

		switch(symtab[k]->type)
		{
		case BLTIN0:		/* FALL THROUGH */
		case BLTIN1:		/* FALL THROUGH */
		case BLTIN2:		/* FALL THROUGH */
		case HEX:		/* FALL THROUGH */
		case STRBLTIN0:		/* FALL THROUGH */
		case STRBLTIN1:		/* FALL THROUGH */
		case STRBLTIN2:
			break;		/* ignore all built-in functions and procedures */

		case NUMBER:		/* FALL THROUGH */
		case VAR:
			if (strcmp("_",symtab[k]->name) == 0)
				break;	/* skip _: last numeric result printed */
#if 0
			(void)fprintf(fpsave, "### DEBUG: name = %s\ttype = %d\n",
				      symtab[k]->name, symtab[k]->type);
#endif
			(void)fprintf(fpsave, "%-23s", symtab[k]->name);
			/* Special handling of PREC: we changed its value! */
			d = (strcmp("PREC", symtab[k]->name) == 0) ?
				(fp_t)old_precision : symtab[k]->u.val;
			(void)fprintf(fpsave, "\t%s",(symtab[k]->immutable ? ":=" : "="));
			if (Nint(d) == d)
				(void)fprintf(fpsave, " %s\n", fmtnum(d));
			else
				(void)fprintf(fpsave, " %s\t# %s\n", xdbltos(d), fmtnum(d));
			break;

		case STRING:		/* FALL THROUGH */
		case STRVAR:
#if 0
			(void)fprintf(fpsave, "### DEBUG: name = %s\ttype = %d\n",
				      symtab[k]->name, symtab[k]->type);
#endif
			(void)fprintf(fpsave, "%-23s", symtab[k]->name);
			p = protect(symtab[k]->u.str);
			(void)fprintf(fpsave, "\t%s \"%s\"\n",
				      (symtab[k]->immutable ? ":=" : "="), p);
			efree((void*)p);
			break;

		case FUNCTION:		/* FALL THROUGH */
#if 0
			(void)fprintf(fpsave, "### DEBUG: name = %s\ttype = %d\n",
				      symtab[k]->name, symtab[k]->type);
			(void)fprintf(fpsave, "### NOT-YET-IMPLEMENTED: func %s(){...}\n",
				      symtab[k]->name);
#endif
			break;

		case PROCEDURE:
#if 0
			(void)fprintf(fpsave, "### DEBUG: name = %s\ttype = %d\n",
				      symtab[k]->name, symtab[k]->type);
			(void)fprintf(fpsave, "### NOT-YET-IMPLEMENTED: proc %s(){...}\n",
				      symtab[k]->name);
#endif
			break;

		default:
			break;
		}
	}

	(void)set_precision(old_precision);
}

fp_t
strton(const char *s, char **endptr)
{					/* string to number (generalized strtod()) */
	const char *t;
	fp_t result;
	int sign;

	while (isspace(*s))		/* skip leading space */
		++s;

	if (*s == '-')
	{
		s++;
		sign = -1;
	}
	else if (*s == '+')
	{
		s++;
		sign = 1;
	}
	else
		sign = 1;

	t = Tolower(s);

	if (endptr != (char**)NULL)
		*endptr = (char*)strchr(s,'\0');

	/* C99 allows "NAN(n-char-sequence)" (and SGI IRIX already
	produces this in C89), but we don't check for a close
	parenthesis: C99 leaves it implementation dependent whether
	the parentheses are balanced. */

	if ((strcmp(t,"nan") == 0) || (strncmp(t,"nan(",4) == 0))
		result = NaN();
	else if ((strcmp(t,"qnan") == 0) || (strncmp(t,"qnan(",5) == 0))
		result = QNaN();
	else if ((strcmp(t,"snan") == 0) || (strncmp(t,"snan(",5) == 0))
		result = SNaN();
	else if ((strcmp(t,"inf") == 0) || (strcmp(t,"infinity") == 0))
		result = Infinity();
	else
	{
		char *t_endptr;

		/* Try the hexadecimal form first, and if that fails, use
		   whatever native strtod() returns */
		result = xstrtod(t, &t_endptr);

		if (*t_endptr != '\0')
			result = (fp_t)strtod(t, &t_endptr);

		if (endptr != (char**)NULL)
			*endptr = (char*)(s + (t_endptr - t));
	}
	efree((void*)t);
	if (sign < 0)
		result = -result;
	return (result);
}

const char *
Tolower(const char *s)
{	/* return a dynamic copy of s, converted to lowercase */
	char *t;
	char *p;

	t = (char *)dupstr(s);
	for (p = t; *p; ++p)
		*p = (isupper(UC(*p)) ? tolower(UC(*p)) : *p);

	return (t);
}

const char *
Toupper(const char *s)
{	/* return a dynamic copy of s, converted to uppercase */
	char *t;
	char *p;

	t = (char *)dupstr(s);
	for (p = t; *p; ++p)
		*p = (islower(UC(*p)) ? toupper(UC(*p)) : *p);

	return (t);
}

const char *
xdbltos(fp_t x)
{
	/* Convert a floating-point value to a hexadecimal floating-point
	   string, returning a pointer to a static internal buffer which will be
	   OVERWRITTEN on the next call.  The conversion is defined by the
	   description of the fprintf() %A and %a format items in

		``ISO/IEC 9899:1999 (E) Programming languages -- C'', Section
		7.19.6.1, p. 278:

	``a,A	A double argument representing a floating-point number is
		converted in the style [-]0xh.hhhhp+-d, where there is one
		hexadecimal digit (which is nonzero if the argument is a
		normalized floating-point number and is otherwise unspecified)
		before the decimal-point character
			[Footnote 235: Binary implementations can choose the
			hexadecimal digit to the left of the decimal-point
			character so that subsequent digits align to nibble
			(4-bit) boundaries.]
		and the number of hexadecimal digits after it is equal to the
		precision; if the precision is missing and FLT_RADIX is a power
		of 2, then the precision is sufficient for an exact
		representation of the value; if the precision is missing and
		FLT_RADIX is not a power of 2, then the precision is sufficient
		to distinguish
			[Footnote 236: The precision p is sufficient to
			distinguish values of the source type if 16^(p-1) > b^n
			where b is FLT_RADIX and n is the number of base-b
			digits in the significand of the source type. A smaller
			p might suffice depending on the implementation's scheme
			for determining the digit to the left of the
			decimal-point character.]
		values of type double, except that trailing zeros may be
		omitted; if the precision is zero and the # flag is not
		specified, no decimal point character appears. The letters
		abcdef are used for %a conversion and the letters ABCDEF for %A
		conversion. The A conversion specifier produces a number with X
		and P instead of x and p. The exponent always contains at least
		one digit, and only as many more digits as necessary to
		represent the decimal exponent of 2. If the value is zero, the
		exponent is zero.

		A double argument representing an infinity or NaN is converted
		in the style of an f or F conversion specifier.

		... ''

	   In this implementation, we choose to trim trailing zeros, leaving at
	   least one digit following the hexadecimal point.   We also make a
	   distinction between quiet and signalling NaNs, and include the
	   sign of the NaN. */

#if defined(HAVE_IEEE_754)
	/* This implementation requires knowledge of low-level formatting of
	   IEEE 754 64-bit floating-point data:

	bit:	6666555555555544444444443333333333222222222211111111110000000000
		3210987654321098765432109876543210987654321098765432109876543210
	data:	seeeeeeeeeeeffffffffffffffffffffffffffffffffffffffffffffffffffff
		|           ----------------------------------------------------
		|-----------                         |--significand
		|    |--exponent
		|--sign

	The binary point occurs before the significand, after the hidden bit,
	which is nonzero if the number is normalized, and zero otherwise. */

	static char s[sizeof("-0xd.ffffffffffffffffp+dddd")];
	double signif;
	DoubleParts d;
	int expon;
	unsigned int hi, lo;

	int big_endian = IsBigEndian();

	if (IsNaN(x))
		return (NaN_string(x));
	else if (IsInf(x))
		return (Inf_string(x));
	else if (x == 0.0)
		return ("0");
	else
	{
		char *last;
		signif = Significand(x);
		expon = (int)Exponent(x);
		d.v = signif;
		hi = d.i[1-big_endian];
		lo = d.i[big_endian];

		(void)sprintf(s, "%s0x%d.%05x%08x",
			      ((x < 0.0) ? "-" : "+"),
			      1, /* (int)IsNormal(x), */
			      (0x000fffff & hi),
			      lo);

		/* Trim trailing zeros */
		last = strchr(s,'\0') - 1;
		while ((last[0] == '0') && (last[-1] != '.'))
			last--;

		(void)sprintf(last + 1, "p%s%d",
			      ((expon < 0) ? "-" : "+"),
			      ((expon < 0) ? -expon : expon));
	}
#else /* cannot fiddle bits without further details, so fall back to decimal output */
	static char s[sizeof("-1.234567890123456789012345678901234567890E+dddd")];
	sprintf(s,"%.17lg",(double)x);	/* use %.35lg for 128-bit precision */
#endif /* defined(HAVE_IEEE_754) */

	return ((const char*)&s[0]);
}

const char *
xinttos(fp_t x)
{
	/* Convert x to a hexadecimal integer, if this is exactly
	   representable, and otherwise, to a hexadecimal
	   floating-point value. */

#if defined(HAVE_IEEE_754)

#if (HAVE_LONG_LONG)
#define MAXINT	9007199254740991.0	/* 2^53 - 1 */
#else
#define MAXINT	4294967295.0		/* 2^32 - 1 */
#endif

	UNSIGNED_LONG_LONG n;
	fp_t xabs;

	if (IsNaN(x))
		return (xdbltos(x));
	else if (IsInf(x))
		return (xdbltos(x));
	else if ( (x < -MAXINT) || (MAXINT < x) || (x != Nint(x)) )
		return (xdbltos(x));	/* not representable as integer */
	else
	{
		static char buffer[sizeof("-0xhhhhhhhhhhhhhh")];
		char *p;

		xabs = (x < 0) ? -x : x;
		n = (UNSIGNED_LONG_LONG)xabs;	/* exact conversion */
		p = &buffer[elementsof(buffer)-1];
		*p-- = '\0';
		while (p >= &buffer[2])	/* leave room for "-0x" */
		{
			static const char hexchars[] = "0123456789abcdef";

			*p-- = hexchars[n & 0xf];
			n >>= 4;
			if (n == 0)
				break;
		}
		*p-- = 'x';
		*p-- = '0';
		if (x < 0)
			*p = '-';
		else
			*p = '+';
		return ((const char*)p);
	}
#else	/* NOT defined(HAVE_IEEE_754) */
	/* Use fallback of hexadecimal floating-point for now, but
	   ultimately, special case code is needed here for other
	   floating-point systems. */
	return (xdbltos(x));
#endif	/* defined(HAVE_IEEE_754) */

}

#define XSTRTOD_FAILURE (0.0)	/* mandated by C89 and C99 (*endptr disambiguates) */

fp_t
xstrtod(const char* s, char **endptr)
{	/* Convert C99 hexadecimal floating-point string
		   "[-+]?0[Xx][0-9A-Fa-z]*(.[0-9A-Fa-z])?[Pp][-+]?[0-9]+"
	   to floating-point. */
	fp_t d;
	int digit;
	int binary_power;
	int nfract;
	int nsign;

	while (isspace(*s))
		++s;
	if (*s == '-')
	{
		s++;
		nsign = -1;
	}
	else if (*s == '+')
	{
		s++;
		nsign = 1;
	}
	else
		nsign = 1;

	if (strncmp(s,"0x",2) != 0)
	{
		if (endptr != (char**)NULL)
			*endptr = (char*)s;
		return (XSTRTOD_FAILURE);
	}
	s += 2;
	for (d = 0.0; (digit = hexval(*s), digit) >= 0; ++s)
		d = 16.0 * d + (fp_t)digit;
	nfract = 0;
	if (*s == '.')
	{
		s++;
		for ( ; (digit = hexval(*s), digit) >= 0; ++s, ++nfract)
			d = 16.0 * d + (fp_t)digit;
	}
	binary_power = 0;
	if ((*s == 'p') || (*s == 'P'))
	{
		int exponent_sign;
		int n_exponent_digits;

		++s;
		if (*s == '-')
		{
			s++;
			exponent_sign = -1;
		}
		else if (*s == '+')
		{
			s++;
			exponent_sign = 1;
		}
		else
			exponent_sign = 1;

		for (n_exponent_digits = 0; (digit = decval(*s), digit) >= 0; ++s, n_exponent_digits++)
			binary_power = 10 * binary_power + digit;
		if (n_exponent_digits == 0)
		{
			if (endptr != (char**)NULL)
				*endptr = (char*)s;
			return (XSTRTOD_FAILURE);
		}
		if (exponent_sign < 0)
			binary_power = -binary_power;
	}
	d = ldexp(d, -4 * nfract + binary_power);
	if (endptr != (char**)NULL)
		*endptr = (char*)s;
	return ((nsign < 0) ? -d : d);
}
